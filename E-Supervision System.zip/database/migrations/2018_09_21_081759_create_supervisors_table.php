<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSupervisorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('supervisors', function (Blueprint $table) {
            $table->increments('supervisor_id');
            $table->string('supervisor_firstName')->default('NULL');
            $table->string('supervisor_lastName')->default('NULL');
            $table->string('supervisor_email')->unique();
            $table->string('supervisor_image')->default('NULL');
            $table->string('supervisor_designation')->default('NULL');
            $table->string('supervisor_department')->default('NULL');
            $table->string('supervisor_phone')->default('NULL');
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('supervisors');
    }
}
