->default('NULL')<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFirstStudentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('first_students', function (Blueprint $table) {
            $table->increments('fStudent_id');
            $table->string('fStudent_name')->default('NULL');
            $table->string('fStudent_sID')->default('NULL');
            $table->string('fStudent_email')->default('NULL');
            $table->string('fStudent_phone')->default('NULL');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('first_students');
    }
}
