<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateThirdStudentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('third_students', function (Blueprint $table) {
            $table->increments('tStudent_id');
            $table->string('tStudent_name')->default('NULL');
            $table->string('tStudent_sID')->default('NULL');
            $table->string('tStudent_email')->default('NULL');
            $table->string('tStudent_phone')->default('NULL');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('third_students');
    }
}
