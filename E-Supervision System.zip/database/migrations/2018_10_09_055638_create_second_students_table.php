<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSecondStudentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('second_students', function (Blueprint $table) {
           $table->increments('sStudent_id');
            $table->string('sStudent_name')->default('NULL');
            $table->string('sStudent_sID')->default('NULL');
            $table->string('sStudent_email')->default('NULL');
            $table->string('sStudent_phone')->default('NULL');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('second_students');
    }
}
