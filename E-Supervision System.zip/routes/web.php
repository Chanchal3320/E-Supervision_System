<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


/*----- Welcome Page ------ */
Route::get('/','Auth\LoginController@showLoginForm'); 





Auth::routes();



Route::group(['middleware' => ['admin']], function () {


Route::get('/admin', 'AdminController@index')->name('admin');

/* ------------- For Faculty----------------- */
Route::get('/addFaculty','FacultyController@index');
Route::post('/addFaculty','FacultyController@addFaculty');
Route::post('/editFaculty','FacultyController@editFaculty');

/*---- Department Route ---------*/
Route::get('/allDepartment','FacultyController@allDepartmentList');
Route::post('/saveDepartmentInfo','FacultyController@saveDepartmentInfo');
Route::post('/editDepartmentInfo','FacultyController@editDepartmentInfo');

 /*---------- Student Group --------- */
Route::get('/singleGroupDetails/{project_id}','ProjectController@singleGroupDetails');

/*-------- Project Information Route -----*/
Route::get('/allProjectList','StudentGroupController@allProjectList');

Route::get('/listStudentGroup','StudentGroupController@listStudentGroup');

Route::get('/viewProjectInfo/{project_id}','ProjectController@viewProjectInfo');

Route::get('/projectStatus/{project_id}','ProjectController@projectStatus');

     /*--------- For Supervisor -------- */

 
Route::get('/manageSupervisor','SupervisorController@manageSupervisor'); 
Route::get('/showProfile/{supervisor_id}','SupervisorController@viewProfile');
Route::get('/editProfile/{supervisor_id}','SupervisorController@editProfileView');
Route::post('/editProfile','SupervisorController@editProfile');
}); 





Route::group(['middleware' => ['student']], function () {
    Route::get('/student', 'StudentGroupController@studentHome')->name('student');

    Route::get('/student/listStudentGroup','StudentGroupController@viewStudentGroup');
    Route::get('/student/viewGroupDetails/{project_id}','ProjectController@viewGroupDetails');
    Route::get('/student/projectList','ProjectController@projectList');

    
    Route::get('/student/allSupervisorList','SupervisorController@allSupervisortList');


    Route::get('/student/viewSupervisorProfile/{supervisor_id}','SupervisorController@viewSupervisorProfile');


    Route::get('/student/sendRequest/{id}','NotificationController@sendRequest');



     /*-------- First Student Information Route --------*/
Route::get('/student/addStudentGroup','StudentGroupController@index');
Route::post('/student/fStudentInfo','StudentGroupController@fStudentInfoAdd');

/*----- Second Student Information Route ------*/
Route::get('/student/sStudentInfo','StudentGroupController@sStudentInfo');
Route::post('/student/sStudentInfo','StudentGroupController@sStudentInfoAdd');

/*----- Third Student Information Route ------*/
Route::get('/student/tStudentInfo','StudentGroupController@tStudentInfo');
Route::post('/student/tStudentInfo','StudentGroupController@tStudentInfoAdd');

/*------ Project Route ---------*/
Route::get('/student/projectForm','StudentGroupController@formProject');
Route::post('/student/addProject','StudentGroupController@addProjectInfo');


Route::post('/student/sendMail','MailController@sendMail');


Route::get('/student/profile','StudentGroupController@viewProfile');





});








Route::group(['middleware' => ['supervisor']], function () {
    Route::get('/supervisor', 'SupervisorController@supervisorHome')->name('supervisor');




    Route::get('/supervisor/facultyList', 'FacultyController@facultyList');
    Route::get('/supervisor/departmentList', 'FacultyController@departmentList');
    Route::get('/supervisor/listStudentGroup','StudentGroupController@sviewStudentGroup');
    Route::get('/supervisor/viewGroupDetails/{project_id}','SupervisorController@sViewGroupDetails');
    Route::get('/supervisor/allProjectList','ProjectController@sprojectList');
    Route::get('/supervisor/allSupervisor','SupervisorController@supervisorList');
    Route::get('/supervisor/viewSupervisorProfile/{supervisor_id}','SupervisorController@singleSupervisorProfile');
    Route::get('/supervisor/editSupervisorForm/{supervisor_id}','SupervisorController@SupervisorEditForm');
    Route::post('/supervisor/updateSupervisorProfile','SupervisorController@SupervisorUpdateInfo');


    Route::get('/supervisor/addSupervisor','SupervisorController@index');
    Route::post('/supervisor/addSupervisorInfo','SupervisorController@addSupervisorInfo');



    /* -------  For Supervisor Research ------ */


Route::post('/supervisor/addResearch','ResearchController@store');

Route::get('/supervisor/deleteResearch/{research_id}','ResearchController@delete');
Route::get('/supervisor/firstResearch','ResearchController@firstResearch');
Route::post('/supervisor/saveFirstResearch','ResearchController@saveFirstResearch');





Route::get('/supervisor/deleteResearch/{research_id}','ResearchController@delete');


/*-------- Project Route ---------*/

Route::get('/supervisor/projectStatus/','ProjectController@statusProject');










  /*-------- For Counselling --------- */

 Route::post('/supervisor/addCounsellingTime','CounsellingController@addCounselling');
 Route::get('/supervisor/deleteCounselling/{counselling_id}','CounsellingController@deleteCounselling');


 


 Route::get('/supervisor/firstCounselling','CounsellingController@firstCounselling');
 Route::post('/supervisor/saveFirstCounselling','CounsellingController@saveFirstCounselling');


/*-------- Notification System --------*/
Route::get('/supervisor/confirmRequest/{id}','NotificationController@confirmRequest');
Route::get('/supervisor/deleteRequest/{id}','NotificationController@deleteRequest');


Route::get('/supervisor/profile','SupervisorController@profile');
Route::get('/supervisor/studentProfile','StudentGroupController@studentProfile');



});





