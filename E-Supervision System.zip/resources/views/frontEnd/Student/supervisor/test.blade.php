  <!-- Bordered Table -->
                    <div class="block">
                        
                        <div class="block-content">
                            <table class="table table-bordered table-vcenter">
                                <thead>
                                    <tr>
                                        <th class="text-center" style="width: 50px;">#</th>
                                        <th>Image</th>
                                        <th>Full Name</th>
                                        
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Designation</th>
                                        <th>Department</th>
                                        
                                       
                                        <th class="text-center" style="width: 100px;">Actions</th>
                                    </tr>
                                </thead>

                                 <?php 
                                  // $i = 1;

                                ?>
                                <tbody>
                                  @foreach($supervisors as $supervisor)
                                  
                                  
                                    
                                    
                                    <tr>
                                        <th class="text-center" scope="row">{{$i++}}</th>
                                        <td><img src="{{asset($supervisor ->supervisor_image)}}" alt="" width="50px" height="50px"></td>
                                        <td>{{$supervisor -> supervisor_firstName.' ' .' '.$supervisor -> supervisor_lastName  }}</td>
                                        
                                        <td>{{$supervisor -> supervisor_email }}</td>
                                        <td>{{$supervisor -> supervisor_phone }}</td>
                                        <td>{{$supervisor ->supervisor_designation }}</td>
                                        <td>{{$supervisor ->supervisor_department }}</td>
                                        
                                        
                                        <td >
                                            <div class="btn-group">
                                              <a href="{{url('/student/viewSupervisorProfile/'.$supervisor->supervisor_id)}}"><button type="button" class="btn btn-sm btn-primary"  title="Show Profile">
                                                    <i class="fa fa-eye"></i>
                                                </button> </a>  &nbsp;


                                               


                                              

                                            </div>
                                        </td>
                                    </tr>

                                @endforeach




                                </tbody>
                            </table>
                        </div>
                    </div> -->
                    <!-- END Bordered Table -->