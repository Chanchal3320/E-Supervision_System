 @extends('frontEnd.Student.master')

@section('title')

ESS || Supervisor List

@endsection


@section('mainContent')


@include('frontEnd.Student.includes.sidebar')

<!-- Main Container -->
<main id="main-container">

    

    <!-- Page Content -->
    <div class="content">
        <h2 class="content-heading">All Supervisor List</h2>
            <div class="row">

                @foreach($supervisors as $supervisor)
                <div class="col-md-3">
                    
                     <div class="card" >
                      <img class="card-img-top" src="{{asset($supervisor ->supervisor_image)}}" alt="Card image cap" >
                      <div class="card-body">
                        <h5 class="card-title text-center">{{$supervisor -> supervisor_firstName.' ' .' '.$supervisor -> supervisor_lastName  }}</h5>
                        <p class="card-text text-center">Phone: {{$supervisor -> supervisor_phone }} </p>
                        <p class="card-text text-center">Email: {{$supervisor ->email }} </p>


                        <?php 



                            $check = DB::table('notifications')
                                ->where('user_requested','=', $supervisor->id)
                                ->where('requester','=',Auth::user()->id)
                                ->first();


                            if ($check == '') {
                        ?>



                        <a href="{{url('/student/sendRequest/'.$supervisor->id)}}" class="btn btn-rounded  btn-sm btn-alt-success">Send Request</a>

                        <?php 
                        }

                        else{  ?>

                            

                            <button class="btn btn-rounded  btn-sm btn-alt-success" disabled > Request Sent</button>

                            <?php }  ?>

                        <a href="{{url('/student/viewSupervisorProfile/'.$supervisor->supervisor_id)}}" class="btn btn-rounded  btn-sm btn-alt-primary">View Profile</a>
                      </div>
                    </div>
                </div>


                @endforeach
            </div>

           
       

       
    </div>
    <!-- END Page Content -->
</main>
<!-- END Main Container -->


@endsection