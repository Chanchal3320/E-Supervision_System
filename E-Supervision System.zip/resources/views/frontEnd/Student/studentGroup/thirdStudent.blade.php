@extends('frontEnd.Student.master')

@section('title')

ESS || Student Group List

@endsection


@section('mainContent')


@include('frontEnd.Student.includes.sidebar')

<!-- Main Container -->
<main id="main-container">

        
    <h3 style="text-align: center" class="text-success">
        
        {{Session::get('message')}}
    </h3>

    <!-- Page Content -->
    <div class="content">
        <!-- Material Design -->
        <h2 class="content-heading">ADD STUDENT INFORMATION</h2>  
            <div class="row">
                    <div class="col-md-8 offset-md-2 ">
                        <!-- Floating Labels -->
                        <div class="block">
                            
                            <div class="block-content">
                                <form method="post" action="{{url('/student/tStudentInfo')}}" onsubmit="return emailValidation()" name="studentForm">
                                    @csrf
                                        <div class="block">
                                            <div class="block-header block-header-default">
                                                <h3 class="block-title">Third Student Information</h3>
                                                
                                            </div>
                                            <div class="block-content">
                                                <div class="form-group row">
                                                    <div class="col-md-9">
                                                        <div class="form-material floating">
                                                            <input type="text" class="form-control" id="material-text2" name="tStudent_name">
                                                            <label for="material-text2">Name</label>
                                                        </div>
                                                    </div>
                                                </div>

                                                   <div class="form-group row">
                                                    
                                                        <div class="col-md-3">
                                                            <div class="form-material floating">
                                                                <input type="text" class="form-control text-md-center" id="material-text2" name="tStudent_batch">
                                                                <label for="material-text2">Student ID</label>
                                                            </div>
                                                        </div>

                                                         <div class="col-md-3">
                                                            <div class="form-material floating">
                                                                <input type="text" class="form-control text-md-center" id="material-text2" value="15" name="dept_code" disabled>
                                                               
                                                            </div>
                                                        </div>
                                                    

                                                     <div class="col-md-3">
                                                            <div class="form-material floating">
                                                                <input type="text" class="form-control text-md-center" id="material-text2" name="tStudent_sID">
                                                                
                                                            </div>
                                                        </div>                                                 
                                                    
                                                </div>

                                                <div class="form-group row">
                                                    <div class="col-md-9">
                                                        <div class="form-material floating">
                                                            <input type="text" class="form-control" id="material-text2" name="tStudent_email">
                                                            <label for="material-text2">Email</label>
                                                        </div>
                                                        <span id="error"></span>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <div class="col-md-9">
                                                        <div class="form-material floating">
                                                            <input type="text" class="form-control" id="material-text2" name="tStudent_phone">
                                                            <label for="material-text2">Phone</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="block-options">
                                                    <button class="btn btn-sm btn-alt-primary" type="submit">
                                                        <i class="fa fa-check"></i> Submit
                                                    </button>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                            </div>
                        </div>
                        <!-- END Floating Labels -->
                    </div>
                 




                   
                </div> <!-- wizard container -->
            </div>



    </div>
        <!-- END Material Design -->
   
</main>
<!-- END Main Container -->


<script>
    
 function emailValidation() {
        var em = document.studentForm.tStudent_email.value;

       
       

        if(em.charAt(em.length-3 && em.length-7)!="."){
            var r = document.getElementById("error") ;   

             

             if(r){
                window.alert(" INVALID EMAIL PLEASE ENTER DIU EMAIL ADDRESS..!!");
             }



            return false;
        }

       


    }
    


</script>

@endsection




