<!doctype html>
 <html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="no-focus"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
     <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>@yield('title')</title>

        

        <!-- Icons -->
        <!-- The following icons can be replaced with your own, they are used by desktop and mobile browsers -->
       @include('frontEnd.Student.includes.link')
        <!-- You can include a specific file from css/themes/ folder to alter the default color theme of the template. eg: -->
        <!-- <link rel="stylesheet" id="css-theme" href="backEnd/css/themes/flat.min.css"> -->
        <!-- END Stylesheets -->
    </head>
    <body>
        
        <div id="page-container" class="sidebar-o side-scroll page-header-modern main-content-boxed">
            

           
           
           
           @include('frontEnd.Student.includes.sidebar')
           @include('frontEnd.Student.includes.header')

       

            @yield('mainContent')

            @include('frontEnd.Student.includes.footer')
        </div>
        <!-- END Page Container -->

        @include('frontEnd.Student.includes.script')
    </body>
</html>