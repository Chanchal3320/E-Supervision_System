@extends('frontEnd.Student.master')

@section('title')

ESS || Student Profile
 
@endsection


@section('mainContent')
@include('frontEnd.student.includes.sidebar')


 <!-- Main Container -->
<main id="main-container" >
    <!-- Page Content -->
    <!-- User Info -->
    <div class="bg-image bg-image-bottom" style="background-image: url('assets/img/photos/photo13@2x.jpg');">
        <div class="bg-primary-dark-op py-30">
            <div class="content content-full text-center">
                <!-- Avatar -->
                <div class="mb-15">
                    <a class="img-link" href="">
                        <img class="img-avatar img-avatar96 img-avatar-thumb" src="{{asset($studentProfile->user_image)}}" alt="">
                    </a>
                </div>
                <!-- END Avatar -->

                <!-- Personal -->
                <h1 class="h3 text-white font-w700 mb-10">{{$studentProfile->name}}</h1>
                <h2 class="h5 text-white-op">
                    Email:  <a class="text-primary-light" href="javascript:void(0)">{{$studentProfile->email}}</a>
                </h2>
                <!-- END Personal -->

                <!-- Actions -->
                
                
                <!-- END Actions -->
            </div>
        </div>
    </div>
    <!-- END User Info -->

  
        
       

</main>
<!-- END Main Container -->

  


@endsection