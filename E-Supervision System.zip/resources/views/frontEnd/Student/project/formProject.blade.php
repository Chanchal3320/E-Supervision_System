   
@extends('frontEnd.Student.master')

@section('title')

ESS || Add Project Details

@endsection


@section('mainContent')


@include('frontEnd.Student.includes.sidebar')
<!-- Main Container -->
<main id="main-container">

        
    <h3 style="text-align: center" class="text-success">
        
        {{Session::get('message')}}
    </h3>

    <!-- Page Content -->
    <div class="content">
        <!-- Material Design -->
        <h2 class="content-heading">ADD PROJECT INFORMATION</h2>  
            <div class="row">
                 <div class="col-md-8 offset-md-2 ">
                        <!-- Floating Labels -->
                        <div class="block">
                            
                            <div class="block-content">
                               <form action="{{url('/student/addProject')}}" method="post">
                                   @csrf
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="material-icons"></i>
                                    </span>
                                    <div class="form-group label-floating">
                                      <label class="control-label">Project Name <small>*</small></label>
                                      
                                      <input name="project_name" type="text" class="form-control">
                                    </div>
                                </div>

                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="material-icons"></i>
                                    </span>
                                    <div class="form-group label-floating">
                                      <label class="control-label">Project Sector <small>*</small></label>
                                      
                                      <input name="project_sector" type="text" class="form-control">
                                    </div>
                                </div>


                                
                                 <div class="input-group">
                                        <span class="input-group-addon">
                                            <i class="material-icons"></i>
                                        </span>
                                        <div class="form-group label-floating">
                                          <label class="control-label">Project Length (month)<small>*</small></label>
                                          <input name="project_length"  type="text" class="form-control">
                                        </div>
                                    </div>


                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <i class="material-icons"></i>
                                        </span>
                                        <div class="form-group label-floating">
                                          <label class="control-label">Project Details <small>*</small></label>
                                          <textarea name="project_details" id="" cols="20" rows="5" class="form-control"></textarea>
                                        </div>
                                    </div>

                                 



                              

                              </div>
                              <div class="modal-footer">
                                 
                                <button type="submit" class="btn btn-success" >SUBMIT</button>
                                
                              </div>
                                </form>

                                



                            </div>
                        </div>
                        <!-- END Floating Labels -->
                    </div>
                   
                </div> <!-- wizard container -->
            </div>



    </div>
        <!-- END Material Design -->
   
</main>
<!-- END Main Container -->

@endsection

