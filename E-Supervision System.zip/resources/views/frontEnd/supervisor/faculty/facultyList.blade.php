@extends('frontEnd.supervisor.master')

@section('title')

ESS || Supervisor Home
 
@endsection


@section('mainContent')
@include('frontEnd.supervisor.includes.sidebar')


 <!-- Main Container -->
<main id="main-container" class="supervisor_main">
    <!-- Page Content -->
    <div class="content">
        <!-- Default Table Style -->

        <h2 class="content-heading">Faculty List</h2>

      
        
        <div class="col-md-6 offset-md-3">

        <!-- Bordered Table --> 
        <div class="block">
            
            <div class="block-content">
                <table class="table table-bordered table-vcenter">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 50px;">SL</th>
                            

                            <th class="text-center">Faculty Name</th>
                                                                   
                                                             
                            
                        </tr>
                    </thead>

                    <?php 

                        $i = 1;
                    ?>
                   

                    
                    <tbody>
                      @foreach($faculties as $faculty)
                        
                        <tr>
                              <td rowspan="3">{{$i++}}</td>
                            
                            <td class="text-center">{{$faculty->faculty_name}}</td>
                           
                         </tr>


                         @endforeach

                        

                         


                       
                       



                    </tbody>
                </table>
            </div>
        </div>
        <!-- END Bordered Table -->
        
        </div>
      
        <!-- END Default Table Style -->
    </div>
    <!-- END Page Content -->
</main>
<!-- END Main Container -->





@endsection