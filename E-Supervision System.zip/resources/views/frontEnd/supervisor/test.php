 
                    <div class="dropdown">
                      <button class="btn btn-rounded btn-dual-secondary">
                        <i class="fa fa-globe"></i> &nbsp;&nbsp; Notification <span class="badge badge-primary">{{$count}}</span>
                      </button>

                     
                      <div class="dropdown-content">
                         @foreach($requests as $request)
                        <div class="dropdown-item " >
                            
                           <strong>{{$request->name}}</strong> Send Request <br>
                           
                           <form action="">
                            <button type="submit" class="btn btn-sm btn-primary">Confirm</button>
                            </form>

                           <button class="btn btn-sm btn-danger">Delete</button>


                           <!-- <a href="" class="btn btn-sm btn-info">ddd</a> -->
                           <!-- <a href="" class="btn btn-sm btn-info">ddd</a> -->



                            <!--  -->
                        </div>

                       

                         @endforeach
                        
                      </div>

                     
                    </div>