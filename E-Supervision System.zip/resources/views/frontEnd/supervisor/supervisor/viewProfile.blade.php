 @extends('frontEnd.supervisor.master')

@section('title')

ESS || Supervisor Profile

@endsection


@section('mainContent')


@include('frontEnd.supervisor.includes.sidebar')

 <!-- Main Container -->
<main id="main-container" class="supervisor_main">
    <!-- Page Content -->
    <!-- User Info -->
    <div class="bg-image bg-image-bottom" style="background-image: url('assets/img/photos/photo13@2x.jpg');">
        <div class="bg-primary-dark-op py-30">
            <div class="content content-full text-center">
                <!-- Avatar -->
                <div class="mb-15">
                    <a class="img-link" href="">
                        <img class="img-avatar img-avatar96 img-avatar-thumb" src="{{asset($profileById->supervisor_image)}}" alt="">
                    </a>
                </div>
                <!-- END Avatar -->

                <!-- Personal -->
                <h1 class="h3 text-white font-w700 mb-10">{{$profileById->supervisor_firstName.' ' . $profileById->supervisor_lastName}}</h1>
                <h2 class="h5 text-white-op">
                    Email:  <a class="text-primary-light" href="javascript:void(0)">{{$profileById->email}}</a>
                </h2>
                <!-- END Personal -->

                <!-- Actions -->
                
                <button type="button" class="btn btn-rounded btn-hero btn-sm btn-alt-primary mb-5">
                    <i class="fa fa-envelope-o mr-5"></i> Message
                </button>
                <!-- END Actions -->
            </div>
        </div>
    </div>
    <!-- END User Info -->

    <!-- Main Content -->
    <div class="content">
        <!-- Projects -->
        <h2 class="content-heading">
            
            <i class="si si-briefcase mr-5"></i> Researches Topics
        </h2>
         <!-- Bordered Table -->
         <div class="row">
            <div class="col-md-6 offset-md-3">
                   <div class="block">                        
                        <div class="block-content">
                            
                             <h3 style="text-align: center" class="text-success">
        
                                {{Session::get('message')}}
                            </h3>


                            <?php

                            $supervisor_email = $profileById->email;

                            if ($supervisor_email == Auth::user()->email) {

                                ?>

                                <button id="ShowForm" type="button" class="btn btn-primary" data-toggle="modal" data-target="#research_modal" title="Add Research Topics"><i class="fa fa-plus"></i></button>
                            <?php }


                            ?>
                

                             




                            <table class="table table-dark table-bordered table-vcenter">
                                <thead>
                                    <tr>
                                        <th class="text-center" style="width: 50px;">SL</th>
                                        
                                      
                                        <th>Research Topics</th>
                                        <th>Action</th>                                       
                                        <!-- <th class="text-center" style="width: 100px;">Actions</th> -->
                                    </tr>
                                </thead> 

                                <?php
                                    $i = 1;

                                $supervisor_id = $profileById->supervisor_id;
                                // echo $supervisor_id ;


                                $researches = DB::table('researches')
                                        ->where('supervisor_id',$supervisor_id)
                                        ->get();

                                     
                                ?>                              
                                <tbody> 
                                    
                                   @foreach($researches as $research)
                                                          
                                <tr>
                                    <td>{{$i++}}</td>
                                    <td>{{ $research->research_topics}}</td>
                                    <td class="text-center">

                                        
                                        <a href="{{url('/supervisor/deleteResearch/'.$research->research_id)}}">
                                        <button id="ShowForm" type="button" class="btn btn-danger"   title="Edit"><i class="fa fa-trash"></i></button>
                                        </a>


                                        
                                       
                                        




                                    </td>
                                    
                                </tr>
                               @endforeach

                                
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- END Bordered Table -->
            </div>
         </div>
        
        <!-- END Projects -->

        <!-- Colleagues -->
        <h2 class="content-heading">
            
            <i class="si si-users mr-5"></i> Counselling Information
        </h2>
        <div class="row items-push">

            <div class="col-md-8 offset-md-2">
                
                    <!-- Bordered Table -->
                    <div class="block">
                         <h3 style="text-align: center" class="text-success">
        
                                {{Session::get('message')}}
                            </h3>
                

                            



                                <?php

                            $supervisor_email = $profileById->email;

                            if ($supervisor_email == Auth::user()->email) {

                                ?>

                                <button id="ShowForm" type="button" class="btn btn-success" data-toggle="modal" data-target="#counselling_modal" title="Add Research Topics"><i class="fa fa-plus"></i></button>
                            <?php }


                            ?>
                
                        
                        <div class="block-content">
                            <table class="table table-dark table-bordered table-vcenter">
                                <thead>
                                    <tr>
                                        <th class="text-center" style="width: 50px;">SL</th>
                                        
                                       
                                        <th>Counselling Day</th>                                       
                                        <th>Counselling Time</th>                                       
                                        <th>Action</th>                                       
                                        <!-- <th class="text-center" style="width: 100px;">Actions</th> -->
                                    </tr>
                                </thead>

                                <?php 
                                    $i = 1;

                                     $supervisor_id = $profileById->supervisor_id;
                                // echo $supervisor_id ;


                                $counsellings = DB::table('counsellings')
                                        ->where('supervisor_id',$supervisor_id)
                                        ->get();

                                ?>

                              
                                <tbody>
                                    @foreach($counsellings as $counselling)
                                  
                                  <tr>
                                    <td>{{$i++}}</td>
                                    <td>{{$counselling->counselling_day}}</td>
                                    <td>{{$counselling->counselling_time}}</td>
                                    <td>
                                        



                                    <a href="{{url('/supervisor/deleteCounselling/'.$counselling->counselling_id)}}"
                                         id="ShowForm" type="button" class="btn btn-danger"   title="Delete"><i class="fa fa-trash"></i></button>
                                        </a>



                                      
                                    </td>
                                  </tr>
                                  
                                  @endforeach
                                    



                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- END Bordered Table -->

            </div>
            
          
           
        </div>
        <!-- END Colleagues -->                   
    </div>
    <!-- END Main Content -->
    <!-- END Page Content -->
</main>
<!-- END Main Container -->

    @include('frontEnd.supervisor.supervisor.formResearch');

    @include('frontEnd.supervisor.supervisor.formCounselling');
  


@endsection