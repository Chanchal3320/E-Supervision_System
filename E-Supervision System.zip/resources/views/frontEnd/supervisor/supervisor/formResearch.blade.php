<!-- Modal -->
<div id="research_modal" class="modal fade" role="dialog">
  <div class="modal-dialog"> 
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add Research Topics</h4>
      </div>
      <div class="modal-body">
          
         

          <form  action="{{url('/supervisor/addResearch')}}"  method="post"  data-toogle="validator">
                  @csrf 
                 
                 <div class="input-group">
                  <span class="input-group-addon">
                      <i class="material-icons"></i>
                  </span>
                  <div class="form-group label-floating">
                    
                    
                    <input type="hidden" name="supervisor_id" id="supervisor_id" type="text" value="{{$profileById->supervisor_id}}"  class="form-control">
                  </div>
              </div> 
                
               <div class="input-group">
                  <span class="input-group-addon">
                      <i class="material-icons"></i>
                  </span>
                  <div class="form-group label-floating">
                    <label class="control-label">Reaserch Topics <small>*</small></label>
                    
                    <input name="research_topics" id="research_topics" type="text" class="form-control">
                  </div>
              </div> 



              </div>
              <div class="modal-footer">
                
                <button type="submit" id="insertbutton" class="btn btn-success">SUBMIT</button>
              </div>
       </form>  



    </div>
  </div>
</div>

                         