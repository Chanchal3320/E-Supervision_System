   <!-- Modal -->
  <div id="counselling_modal" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Couselling Time</h4>
        </div>
        <div class="modal-body">
           <form action="{{url('/supervisor/addCounsellingTime')}}" method="post">
             @csrf
          <div class="input-group">
              <span class="input-group-addon">
                  <i class="material-icons"></i>
              </span>
              <div class="form-group label-floating">
                
                
                <input type="hidden" value="{{$profileById->supervisor_id}}" name="supervisor_id" type="text" class="form-control">
              </div>
          </div>


          
           <div class="input-group">
                  <span class="input-group-addon">
                      <i class="material-icons"></i>
                  </span>
                  <div class="form-group label-floating">
                    <label class="control-label">Counselling Day <small>*</small></label>
                    <input name="counselling_day" type="text" class="form-control">
                  </div>
              </div>


              <div class="input-group">
                  <span class="input-group-addon">
                      <i class="material-icons"></i>
                  </span>
                  <div class="form-group label-floating">
                    <label class="control-label">Couselling Time <small>*</small></label>
                    <input name="counselling_time" type="text" class="form-control">
                  </div>
              </div>

           



        

        </div>
        <div class="modal-footer">
           
          <button type="submit" class="btn btn-success" >SUBMIT</button>
        </div>
          </form>
      </div>

    </div>
  </div>


