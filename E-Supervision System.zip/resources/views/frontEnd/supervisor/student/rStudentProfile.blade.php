 @extends('frontEnd.supervisor.master')

@section('title')

ESS || Student Profile

@endsection


@section('mainContent')


@include('frontEnd.supervisor.includes.sidebar')




 <!-- Main Container -->
<main id="main-container" class="supervisor_main">
    <!-- Page Content -->
    <!-- User Info -->
    <div class="bg-image bg-image-bottom" style="background-image: url('assets/img/photos/photo13@2x.jpg');">
        <div class="bg-primary-dark-op py-30">
            <div class="content content-full text-center">
                <!-- Avatar -->
                <div class="mb-15">
                    <a class="img-link" href="">
                        <img class="img-avatar img-avatar96 img-avatar-thumb" 
                        src="{{asset($studentProfileView->user_image)}}" alt="">
                    </a>
                </div>
                <!-- END Avatar -->

                <!-- Personal -->
                <h1 class="h3 text-white font-w700 mb-10">{{$studentProfileView->name}}</h1>
                <h2 class="h5 text-white-op">
                    Email:  <a class="text-primary-light" href="javascript:void(0)">{{$studentProfileView->email}}</a>
                </h2>
                <!-- END Personal -->

                <!-- Actions -->
                
                <button type="button" class="btn btn-rounded btn-hero btn-sm btn-alt-primary mb-5">
                    <i class="fa fa-envelope-o mr-5"></i> Message
                </button>
                <!-- END Actions -->
            </div>
        </div>
    </div>
    <!-- END User Info -->

    

       
            
          
           
        </div>
        <!-- END Colleagues -->                   
    </div>
    <!-- END Main Content -->
    <!-- END Page Content -->
</main>
<!-- END Main Container -->

   
  


@endsection