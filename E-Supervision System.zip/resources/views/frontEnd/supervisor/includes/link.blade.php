 <link rel="shortcut icon" href="{{asset('frontEnd/img/favicons/favicon.png')}}">
        <link rel="icon" type="image/png" sizes="192x192" href="{{asset('frontEnd/img/favicons/favicon-192x192.png')}}">
        <link rel="apple-touch-icon" sizes="180x180" href="{{asset('frontEnd/img/favicons/apple-touch-icon-180x180.png')}}">
        <!-- END Icons -->

        <!-- Stylesheets -->
        <!-- Codebase framework -->
        <link rel="stylesheet" id="css-main" href="{{asset('frontEnd/css/codebase.min.css')}}">
        <link rel="stylesheet" id="css-main" href="{{asset('frontEnd/css/material-bootstrap-wizard.css')}}">

 <!-- Page JS Plugins CSS -->
        <link rel="stylesheet" href="{{asset('frontEnd/js/plugins/datatables/dataTables.bootstrap4.min.css')}}">

        <link href="https://fonts.googleapis.com/css?family=Spirax" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Arvo" rel="stylesheet"> 

        <!--     Fonts and icons     -->
	<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />


  {{-- dataTables --}}
       <link href="{{ asset('frontEnd/datatables/css/dataTables.bootstrap.min.css') }}" rel="stylesheet">

      {{-- SweetAlert2 --}}
     <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    {{--   <link href="{{ asset('frontEnd/sweetalert2/sweetalert2.min.css') }}" rel="stylesheet"> --}}





     <script src="{{ asset('frontEnd/bootstrap/js/ie-emulation-modes-warning.js') }}"></script>