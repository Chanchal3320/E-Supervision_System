<!doctype html>
 <html lang="{{ str_replace('_', '-', app()->getLocale()) }}" > <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">

          <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>ESS || Sign IN </title>        

        <!-- Icons -->
        <!-- The following icons can be replaced with your own, they are used by desktop and mobile browsers -->
        <link rel="shortcut icon" href="{{asset('backEnd/img/favicons/favicon.png')}}">
        <link rel="icon" type="image/png" sizes="192x192" href="{{asset('backEnd/img/favicons/favicon-192x192.png')}}">
        <link rel="apple-touch-icon" sizes="180x180" href="{{asset('backEnd/img/favicons/apple-touch-icon-180x180.png')}}"> 
        <!-- END Icons -->

        <!-- Stylesheets -->
        <!-- Codebase framework -->
        <link rel="stylesheet" id="css-main" href="{{asset('backEnd/css/codebase.min.css')}}">

        <!-- You can include a specific file from css/themes/ folder to alter the default color theme of the template. eg: -->
        <!-- <link rel="stylesheet" id="css-theme" href="assets/css/themes/flat.min.css"> -->
        <!-- END Stylesheets -->
    </head>
    <body>
       
<div id="page-container" class="main-content-boxed">
    <!-- Main Container -->
    <main id="main-container">
        <!-- Page Content -->
        <div class="bg-image" style="background-image: url('backEnd/img/photos/photo34@2x.jpg');">
            <div class="row mx-0 bg-black-op">
                <div class="hero-static col-md-6 col-xl-8 d-none d-md-flex align-items-md-end">
                    <div class="p-30 invisible" data-toggle="appear">
                        <p class="font-size-h3 font-w600 text-white">
                            Developed By <strong>DIU Student</strong>
                        </p>
                        <p class="font-italic text-white-op">
                            Copyright &copy; <span class="js-year-copy">2018</span>
                        </p>
                    </div>
                </div>
                <div class="hero-static col-md-6 col-xl-4 d-flex align-items-center bg-white invisible" data-toggle="appear" data-class="animated fadeInRight">
                    <div class="content content-full">
                        <!-- Header -->
                        <div class="px-30 py-10">
                            <a class="link-effect font-w700" href="index.html">
                                <i class="fa fa-graduation-cap fa-2x"></i>
                                <span class="font-size-xl text-primary-dark">E</span><span class="font-size-xl">SS</span>
                            </a>
                            <h1 class="h3 font-w700 mt-30 mb-10">Welcome To Our E-Supervision System</h1>
                            <h2 class="h5 font-w400 text-muted mb-0">Please sign in</h2>
                        </div>
                        <!-- END Header -->

                        

                       
                        <form method="POST" action="{{ route('login') }}" aria-label="{{ __('Login') }}">
                        @csrf
                           {{ csrf_field() }}
                            <div class="form-group row">
                                <div class="col-12">
                                    <div class="form-material floating">
                                        <input type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}"  name="email" id="userEmail" value="{{ old('email') }}" required autofocus placeholder="             example@diu.edu.bd">
                                        <label for="email">Email</label>

                                        @if ($errors->has('email'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('email') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>
                            </div>



                            <div class="form-group row">
                                <div class="col-12">
                                    <div class="form-material floating">
                                        <input type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}"  name="password"  required>
                                        <label for="password" >Password</label>

                                         @if ($errors->has('password'))
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('password') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>
                            </div>


                            <div class="form-group row">
                                <div class="col-12">
                                    <div>
                                        <label  for="login-remember-me">User Type</label>
                                        <select name="role" id="user" class="form-control">
                                            <option value="#">Select User Type</option>
                                            <option value="admin">Admin</option>
                                            <option value="student">Student</option>
                                            <option value="supervisor">Supervisor</option>
                                        </select>


                                        
                                    </div>
                                </div>
                            </div>


                            <div class="form-group">
                                <button type="submit" class="btn btn-sm btn-hero btn-alt-primary">
                                    <i class="si si-login mr-10"></i> Sign In
                                </button>

                                <a href="{{url('/register')}}">
                                <button type="button" class="btn btn-sm btn-hero btn-alt-success">
                                    <i class="si si-login mr-10"></i> Sign UP
                                </button>
                                </a>


                                <div class="mt-30">
                                    
                                    <a class="link-effect text-muted mr-10 mb-5 d-inline-block" href="{{ route('password.request') }}">
                                        <i class="fa fa-warning mr-5"></i> Forgot Password
                                    </a>
                                </div>
                            </div>

                        </form>
                        <!-- END Sign In Form -->




                    </div>
                </div>
            </div>
        </div>
        <!-- END Page Content -->
    </main>
    <!-- END Main Container -->
</div>
<!-- END Page Container -->

        <!-- Codebase Core JS -->
        <script src="{{asset('backEnd/js/core/jquery.min.js')}}"></script>
        <script src="{{asset('backEnd/js/core/bootstrap.bundle.min.js')}}"></script>
        <script src="{{asset('backEnd/js/core/jquery.slimscroll.min.js')}}"></script>
        <script src="{{asset('backEnd/js/core/jquery.scrollLock.min.js')}}"></script>
        <script src="{{asset('backEnd/js/core/jquery.appear.min.js')}}"></script>
        <script src="{{asset('backEnd/js/core/jquery.countTo.min.js')}}"></script>
        <script src="{{asset('backEnd/js/core/js.cookie.min.js')}}"></script>
        <script src="{{asset('backEnd/js/codebase.js')}}"></script>

        <!-- Page JS Plugins -->
        <script src="{{asset('backEnd/js/plugins/jquery-validation/jquery.validate.min.js')}}"></script>

        <!-- Page JS Code -->
        <!-- <script src="{{asset('backEnd/js/pages/op_auth_signin.js')}}"></script> -->
    </body>
</html>