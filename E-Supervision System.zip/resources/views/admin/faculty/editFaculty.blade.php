   <!-- Modal -->
  <div id="edit_faculty" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Faculty Info</h4>
        </div>
        <div class="modal-body">
          <form method="post" action="{{url('/editFaculty')}}">
              @csrf
            <div class="block">
                
                <div class="block-content">
                    <div class="form-group row">
                        <div class="col-md-9">
                            <div class="form-material floating">
                                <input type="hidden" class="form-control"  id="faculty_id" name="faculty_id" value="" >



                                <input type="text" class="form-control"  id="faculty_name" name="faculty_name" >
                                <label for="material-text2">Faculty Name</label>
                            </div>
                        </div>
                    </div>
                    

                  

                 
                </div>
            </div>
        </div>
        <div class="modal-footer">
           
          <button type="submit" class="btn btn-success" >Update</button>
          
        </div>
          </form>
      </div>

    </div>
  </div>




