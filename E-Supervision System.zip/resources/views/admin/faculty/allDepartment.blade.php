@extends('admin.dashboard')

@section('title')

ESS || Add Department
 
@endsection


@section('mainContent')

 <h3 style="text-align: center" class="text-success">
        
        {{Session::get('message')}}
    </h3>

@include('admin.includes.sidebar')




 <!-- Main Container -->
<main id="main-container">
    <!-- Page Content -->
    <div class="content">
        <!-- Default Table Style -->

        <h2 class="content-heading">Department List</h2>

      <button  type="button" class="btn btn-success" data-toggle="modal" data-target="#department_modal">ADD Dept.</button>
        
        <div class="col-md-6 offset-md-3">

        <!-- Bordered Table --> 
        <div class="block">
            
            <div class="block-content">
                <table class="table table-bordered table-vcenter">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 50px;">SL</th>
                            

                            <th class="text-center">Department Name</th>
                                                                   
                                                             
                            <th class="text-center" style="width: 100px;">Actions</th>
                        </tr>
                    </thead>


                    <?php 

                    $i = 1;

                    ?>

                  
                   

                    
                    <tbody>
                        @foreach($departments as $department)
                    
                        
                        <tr>
                              <td >{{$i++}}</td>
                            
                            <td class="text-center"> {{$department->department_name}} </td>
                           
                            
                            
                            <td>

                             
                                <button  type="button" data-department_name="{{$department->department_name}}"
                                data-department_id="{{$department->department_id}}" data-toggle="modal" data-target="#edit_department" class="btn btn-info" ><i class="fa fa-edit"></i></button>
                                
                            </td>
                         </tr>

                    @endforeach
                       

                        

                         


                       
                       



                    </tbody>
                </table>
            </div>
        </div>
        <!-- END Bordered Table -->
        
        </div>
      
        <!-- END Default Table Style -->
    </div>
    <!-- END Page Content -->
</main>
<!-- END Main Container -->



@include('admin.faculty.formDepartment')
@include('admin.faculty.editDepartment')
    
   




@endsection

