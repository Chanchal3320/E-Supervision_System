@extends('admin.dashboard')

@section('title')

ESS || Add Faculty
 
@endsection


@section('mainContent')

 <h3 style="text-align: center" class="text-success">
        
        {{Session::get('message')}}
    </h3>

@include('admin.includes.sidebar')




 <!-- Main Container -->
<main id="main-container">
    <!-- Page Content -->
    <div class="content">
        <!-- Default Table Style -->

        <h2 class="content-heading">Faculty List</h2>

      <button  type="button" class="btn btn-success" data-toggle="modal" data-target="#faculty_modal">ADD Faculty</button>
        
        <div class="col-md-6 offset-md-3">

        <!-- Bordered Table --> 
        <div class="block">
            
            <div class="block-content">
                <table class="table table-bordered table-vcenter">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 50px;">SL</th>
                            

                            <th class="text-center">Faculty Name</th>
                                                                   
                                                             
                            <th class="text-center" style="width: 100px;">Actions</th>
                        </tr>
                    </thead>

                    <?php 

                        $i = 1;
                    ?>
                   

                    
                    <tbody>
                      @foreach($faculties as $faculty)
                        
                        <tr>
                              <td >{{$i++}}</td>
                            
                            <td class="text-center">{{$faculty->faculty_name}}</td>
                           
                            
                            
                            <td>

                             
                                <button   type="button" id="btn_faculty" data-toggle="modal" data-target="#edit_faculty" data-faculty_name="{{$faculty->faculty_name}}" data-faculty_id="{{$faculty->faculty_id}}" class="btn btn-info" ><i class="fa fa-edit"></i></button>
                                
                            </td>
                         </tr>


                         @endforeach

                        

                         


                       
                       



                    </tbody>
                </table>
            </div>
        </div>
        <!-- END Bordered Table -->
        
        </div>
      
        <!-- END Default Table Style -->
    </div>
    <!-- END Page Content -->
</main>
<!-- END Main Container -->



@include('admin.faculty.formFaculty')
@include('admin.faculty.editFaculty')
    
   



@endsection

