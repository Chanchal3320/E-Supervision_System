


@extends('admin.dashboard')

@section('title')

ESS || Add Supervisor
 
@endsection


@section('mainContent')

 <h3 style="text-align: center" class="text-success">
        
        {{Session::get('message')}}
    </h3>

@include('admin.includes.sidebar')




 <!-- Main Container -->
            <main id="main-container">
                <!-- Page Content -->
                <div class="content">
                    <!-- Default Table Style -->
                   


                    <!-- Bordered Table -->
                    <div class="block">
                        
                        <div class="block-content">
                            <table class="table table-bordered table-vcenter">
                                <thead>
                                    <tr>
                                        <th class="text-center" style="width: 50px;">#</th>
                                        
                                        <th>Supervisor ID</th>
                                        <th>Counselling Day</th>                                       
                                        <th>Counselling Time</th>                                       
                                        <th class="text-center" style="width: 100px;">Actions</th>
                                    </tr>
                                </thead>

                               <?php 
                                $i = 1;

                               ?>
                                <tbody>
                                  
                                  
                                  
                                    @foreach($counsellings as $counselling)
                                    
                                    <tr>
                                        <th class="text-center" scope="row">{{$i++}}</th>
                                       
                                        <td>{{$counselling->supervisor_id }}</td>
                                        <td>{{$counselling->counselling_day}}</td>
                                        <td>{{$counselling->counselling_time}}</td>
                                        
                                        
                                        
                                        
                                        <td class="text-center">
                                            <div class="btn-group">
                                              
                                                <button type="button" class="btn btn-sm btn-info" data-toggle="tooltip" title="Edit">
                                                    <i class="fa fa-pencil"></i>
                                                </button>&nbsp;
                                                <button type="button" class="btn btn-sm btn-danger" data-toggle="tooltip" title="Delete">
                                                    <i class="fa fa-times"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>

                                    @endforeach

                               




                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- END Bordered Table -->

                  
                    <!-- END Default Table Style -->
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->



    
   




@endsection

         