


@extends('admin.dashboard')

@section('title')

ESS || Add Supervisor
 
@endsection


@section('mainContent')


@include('admin.includes.sidebar')


  <!-- Main Container -->
            <main id="main-container">
                <!-- Page Content -->
                <div class="content">
                    <!-- Default Table Style -->
                    <h2 class="content-heading">Supervisor List</h2>

                    

                    


                    <!-- Bordered Table -->
                    <div class="block">
                        
                        <div class="block-content">
                            <table class="table table-bordered table-vcenter">
                                <thead>
                                    <tr>
                                        <th class="text-center" style="width: 50px;">#</th>
                                        <th>Image</th>
                                        <th>Full Name</th>
                                        
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Designation</th>
                                        <th>Department</th>
                                        
                                       
                                        <th class="text-center" style="width: 100px;">Actions</th>
                                    </tr>
                                </thead>

                                <?php 
                                  $i = 1;

                                ?>
                                <tbody>
                                  @foreach($supervisors as $supervisor)
                                  
                                  
                                    
                                    
                                    <tr>
                                        <th class="text-center" scope="row">{{$i++}}</th>
                                        <td><img src="{{asset($supervisor ->supervisor_image)}}" alt="" width="50px" height="50px"></td>
                                        <td>{{$supervisor -> supervisor_firstName.' ' .' '.$supervisor -> supervisor_lastName  }}</td>
                                        
                                        <td>{{$supervisor -> email }}</td>
                                        <td>{{$supervisor -> supervisor_phone }}</td>
                                        <td>{{$supervisor ->supervisor_designation }}</td>
                                        <td>{{$supervisor ->supervisor_department }}</td>
                                        
                                        
                                        <td >
                                            <div class="btn-group">
                                              <a href="{{url('/showProfile/'.$supervisor->supervisor_id)}}"><button type="button" class="btn btn-sm btn-warning"  title="Show Profile">
                                                    <i class="fa fa-eye"></i>
                                                </button> </a>  &nbsp;


                                                <a href="{{url('/editProfile/'.$supervisor->supervisor_id)}}"><button type="button" class="btn btn-sm btn-info"  title="Edit Profile">
                                                    <i class="fa fa-pencil"></i>
                                                </button>  </a> &nbsp;


                                               <a href="{{url('/deleteProfile/'.$supervisor->supervisor_id)}}"> <button type="button" class="btn btn-sm btn-danger"  title="Delete Profile">
                                                    <i class="fa fa-times"></i>
                                                </button></a>

                                            </div>
                                        </td>
                                    </tr>

                                @endforeach




                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- END Bordered Table -->

                  
                    <!-- END Default Table Style -->
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->



    
   




@endsection

         