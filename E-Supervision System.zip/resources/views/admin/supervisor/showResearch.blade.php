


@extends('admin.dashboard')

@section('title')

ESS || Add Supervisor
 
@endsection


@section('mainContent')

 <h3 style="text-align: center" class="text-success">
        
        {{Session::get('message')}}
    </h3>

@include('admin.includes.sidebar')




 <!-- Main Container -->
            <main id="main-container">
                <!-- Page Content -->
                <div class="content">
                    <!-- Default Table Style -->

                    <h2 class="content-heading">Supervisor Research List</h2>


                     <div class="Counselling">
                        <a href="{{url('/manageCounselling')}}"><button class="btn btn-sm btn-success" >
                             Counselling Time
                        </button></a>
                    </div>



                    
                  <button id="ShowForm" type="button" class="btn btn-success" data-toggle="modal" data-target="#research_modal"><i class="fa fa-plus"></i></button>
                    


                    <!-- Bordered Table -->
                    <div class="block">
                        
                        <div class="block-content">
                            <table class="table table-bordered table-vcenter">
                                <thead>
                                    <tr>
                                        <th class="text-center" style="width: 50px;">#</th>
                                        
                                        <th>Supervisor ID</th>
                                        <th>Research Topics</th>                                       
                                        <th class="text-center" style="width: 100px;">Actions</th>
                                    </tr>
                                </thead>

                                <?php 
                                  $i = 1;

                                ?>
                                <tbody>
                                  @foreach($researches as $research)
                                  
                                  
                                    
                                    
                                    <tr>
                                        <th class="text-center" scope="row">{{$i++}}</th>
                                       
                                        <td>{{$research -> supervisor_id }}</td>
                                        <td>{{$research -> research_topics }}</td>
                                        
                                        
                                        
                                        
                                        <td class="text-center">
                                            <div class="btn-group">
                                          
                                                <button type="button" class="btn btn-sm btn-info" data-toggle="tooltip" title="Edit">
                                                    <i class="fa fa-pencil"></i>
                                                </button>&nbsp;
                                                <button type="button" class="btn btn-sm btn-danger" data-toggle="tooltip" title="Delete">
                                                    <i class="fa fa-times"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>

                                @endforeach




                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- END Bordered Table -->

                  
                    <!-- END Default Table Style -->
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->


@include('admin.supervisor.formResearch')
    
   




@endsection

         