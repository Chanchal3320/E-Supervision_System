


@extends('admin.dashboard')

@section('title')

ESS || Project Info
 
@endsection


@section('mainContent')

 <h3 style="text-align: center" class="text-success">
        
        {{Session::get('message')}}
    </h3>

@include('admin.includes.sidebar')




 <!-- Main Container -->
<main id="main-container">
    <!-- Page Content -->
    <div class="content">
        <!-- Default Table Style -->

        <h2 class="content-heading">Project Information </h2>

      
        <div class="col-md-8 offset-md-2">


        <!-- Bordered Table --> 
        <div class="block">
            
            <div class="block-content">
                <table class="table table-bordered table-vcenter table-dark">
                    
                        <tr>
                            <th class="text-center" style="width: 50px;">No</th>
                            <td class="text-center" style="width: 50px;">2</td> 
                        </tr>
                        <tr>
                            <th class="text-center" style="width: 50px;">Student Name</th>
                            <td class="text-center" style="width: 50px;">{{$projectById->fStudent_name}}</td> 
                            <td class="text-center" style="width: 50px;">{{$projectById->sStudent_name}}</td> 
                            <td class="text-center" style="width: 50px;">{{$projectById->tStudent_name}}</td> 
                        </tr>
                        <tr>
                            <th class="text-center" style="width: 50px;">Student ID</th>
                            <td class="text-center" style="width: 50px;">{{$projectById->fStudent_sID}}</td> 
                            <td class="text-center" style="width: 50px;">{{$projectById->sStudent_sID}}</td> 
                            <td class="text-center" style="width: 50px;">{{$projectById->tStudent_sID}}</td> 
                        </tr>

                        <tr>
                            <th class="text-center" style="width: 50px;"> Phone Number</th>
                            <td class="text-center" style="width: 50px;">{{$projectById->fStudent_phone}}</td> 
                            <td class="text-center" style="width: 50px;">{{$projectById->sStudent_phone}}</td> 
                            <td class="text-center" style="width: 50px;">{{$projectById->tStudent_phone}}</td> 
                        </tr>

                         <tr>
                            <th class="text-center" style="width: 50px;"> Email</th>
                            <td class="text-center" style="width: 50px;">{{$projectById->fStudent_email}}</td> 
                            <td class="text-center" style="width: 50px;">{{$projectById->sStudent_email}}</td> 
                            <td class="text-center" style="width: 50px;">{{$projectById->tStudent_email}}</td> 
                        </tr>


                        <tr>
                            <th class="text-center" style="width: 50px;">Project Name</th>
                            <td class="text-center" style="width: 50px;">{{$projectById->project_name}}</td> 
                        </tr>


                         <tr>
                            <th class="text-center" style="width: 50px;">Project Length</th>
                            <td class="text-center" style="width: 50px;">{{$projectById->project_length}} month</td> 
                        </tr>

                         <tr>
                            <th class="text-center" style="width: 50px;">Project Description</th>
                            <td class="text-center" style="width: 50px;">{{$projectById->project_details}} </td> 
                        </tr>
                        

                         <tr>
                            <th class="text-center" style="width: 50px;">Status</th>
                             <td class="d-none d-sm-table-cell">
                                
                                   <?php 
                                    if ($projectById->status == 1) {
                                        ?>

                                        <button class="btn btn-sm btn-success" id="btnActive"><span >running</span></button>


                                        <?php
                                    }
                                    else{ ?>

                                         <button class="btn btn-sm btn-danger" id="btnActive"><span >completed</span></button>


                                        <?php

                                    }

                                  ?>
                                
                            </td>
                        </tr>
                    
                  
                    
                    




                    
                </table>
            </div>
        </div>
        <!-- END Bordered Table -->
      </div>
      
        <!-- END Default Table Style -->
    </div>
    <!-- END Page Content -->
</main>
<!-- END Main Container -->



    
   




@endsection

         