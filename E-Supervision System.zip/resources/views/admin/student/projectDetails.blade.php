@extends('admin.dashboard')

@section('title')

ESS || Add Project Info
 
@endsection


@section('mainContent')

 <h3 style="text-align: center" class="text-success">
        
        {{Session::get('message')}}
    </h3>

@include('admin.includes.sidebar')




 <!-- Main Container -->
<main id="main-container">
    <!-- Page Content -->
    <div class="content">
        <!-- Default Table Style -->

        <h2 class="content-heading">Project List</h2>

      
        


        <!-- Bordered Table --> 
        <div class="block">
            
            <div class="block-content">
                <table class="table table-bordered table-vcenter">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 50px;">SL</th>
                            

                            <th class="text-center">Project Name</th>
                            
                            <th class="text-center">Project Length</th>
                            <th class="text-center">Project Details</th>                             
                            <th class="text-center">Status</th>                                       
                            <th class="text-center" style="width: 100px;">Actions</th>
                        </tr>
                    </thead>
                    <?php
                        $i = 1;
                    ?>

                    
                    <tbody>
                         @foreach($projects as $project)
                        
                        <tr>
                              <td >{{$i++}}</td>
                            
                            <td class="text-center">{{$project->project_name }}</td>
                            <td class="text-center">{{$project->project_length  }} Month</td>
                            <td class="text-center">{{$project->project_details  }}</td>
                           
                            <td class="d-none d-sm-table-cell">
                                
                                   <?php 
                                    if ($project->status == 1) {
                                        ?>

                                        <a href="{{url('/projectStatus/'.$project->project_id)}}"><button class="btn btn-sm btn-success" id="btnActive"><span >running</span></button></a>


                                        <?php
                                    }
                                    else{ ?>

                                         <button class="btn btn-sm btn-danger" id="btnActive"><span >completed</span></button>


                                        <?php

                                    }

                                  ?>
                                
                            </td> 
                            
                            <td>

                             <a href="{{url('/viewProjectInfo/'.$project->project_id)}}"   title="View">
                                    

                                <button  type="button" class="btn btn-info" ><i class="fa fa-eye"></i></button>
                                </a> 
                            </td>
                         </tr>

                        

                         


                       
                        @endforeach




                    </tbody>
                </table>
            </div>
        </div>
        <!-- END Bordered Table -->

      
        <!-- END Default Table Style -->
    </div>
    <!-- END Page Content -->
</main>
<!-- END Main Container -->




    
   




@endsection

         