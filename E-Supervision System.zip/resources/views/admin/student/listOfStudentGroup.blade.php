@extends('admin.dashboard')

@section('title')

ESS || Student List

@endsection


@section('mainContent')


@include('admin.includes.sidebar')

<!-- Main Container -->
            <main id="main-container">

                <h3 style="text-align: center" class="text-success">
                    
                    {{Session::get('message')}}
                </h3>

                <!-- Page Content -->
                <div class="content">
                    <h2 class="content-heading">All Student Group List</h2>

                    <!-- Dynamic Table Full -->
                    <div class="block">
                        
                        <div class="block-content block-content-full">
                            <!-- DataTables init on table by adding .js-dataTable-full class, functionality initialized in js/pages/be_tables_datatables.js -->
                            <table class="table table-bordered table-striped table-vcenter js-dataTable-full">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Student Name</th> 
                                        <th>Student ID</th> 
                                        <th>Project Title</th> 
                                        <th>Action</th>                                       
                                        
                                    </tr>
                                </thead>
                                <?php 

                                    $i = 1;
                                ?>
                               
                                <tbody>
                                   @foreach($studentGroupList as $studentGroup)
                                    
                                    <tr>
                                          <td rowspan="3">{{$i++}}</td>



                                        <td class="student_name">{{$studentGroup->fStudent_name}}</td>
                                        <td class="student_id">{{$studentGroup->fStudent_sID}}</td>
                                        <td class="text-center">{{$studentGroup->project_name }}</td>
                                        
                                        <td rowspan="3">

                                         <a href="{{url('/singleGroupDetails/'.$studentGroup->project_id)}}" class="btn btn-info"  title="View">
                                                <span class="fa fa-eye"></span>
                                            </a> 
                                        </td>
                                     </tr>

                                     <tr>
                                        <td class="student_name">{{$studentGroup->sStudent_name}}</td>
                                        <td class="student_id">{{$studentGroup->sStudent_sID}}</td>
                                        
                                     </tr>


                                     <tr>
                                        <td class="student_name">{{$studentGroup->tStudent_name}}</td> 
                                        <td class="student_id">{{$studentGroup->tStudent_sID}}</td> 
                                     </tr>

                                     


                                   
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- END Dynamic Table Full -->

                   

                   
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->


@endsection