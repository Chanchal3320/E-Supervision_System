@extends('dashboard')

@section('title')

ESS || Add Teacher

@endsection


@section('mainContent')


@include('admin.includes.sidebar')

<!-- Main Container -->
<main id="main-container">
    <!-- Page Content -->
    <div class="content">
        <!-- Material Design -->
        <h2 class="content-heading">ADD TEACHER INFORMATION</h2>
        <div class="row">
          
            <div class="col-md-6 offset-md-3 ">
                <!-- Floating Labels -->
                <div class="block">
                    
                    <div class="block-content">
                        <form action="{{url('/addTeacher')}}" method="post" enctype="multipart/form-data">

                            @csrf
                            <div class="form-group row">
                                <div class="col-md-9">
                                    <div class="form-material floating">
                                        <input type="text" class="form-control" id="material-text2" name="firstName">
                                        <label for="material-text2">First Name</label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-9">
                                    <div class="form-material floating">
                                        <input type="text" class="form-control" id="material-text2" name="lastName">
                                        <label for="material-text2">Last Name</label>
                                    </div>
                                </div>
                            </div>


                            <div class="form-group row">
                                <div class="col-md-9">
                                    <div class="form-material floating">
                                        <input type="text" class="form-control" id="material-text2" name="userName">
                                        <label for="material-text2">User Name</label>
                                    </div>
                                </div>
                            </div>



                           
                            <div class="form-group row">
                                <div class="col-12">
                                    <div class="form-material floating">
                                        <input type="email" class="form-control" id="material-email2" name="teacherEmail">
                                        <label for="material-email2">Email</label>
                                    </div>
                                </div>
                            </div>
                           
                            
                               
                            <div class="form-group row">
                                <div class="col-12">
                                    <div class="form-material floating">
                                        <textarea class="form-control" id="material-textarea-small2" name="about" rows="3"></textarea>
                                        <label for="material-textarea-small2">About</label>
                                    </div>
                                </div>
                            </div>


                            <div class="form-group row">
                                <div class="col-12">
                                    <div class="form-material floating">
                                        <select name="faculty" id="faculty" class="form-control">
                                        	<option value="#">Select Faculty</option>
                                        	<option value="FSIT">FSIT</option>
                                        	<option value="NS">NS</option>
                                        	<option value="English">English</option>
                                        	<option value="LLB">LLB</option>
                                        </select>
                                        <!-- <label for="material-textarea-small2">Faculty</label> -->
                                    </div>
                                </div>
                            </div>

                             <div class="form-group row">
                                <div class="col-12">
                                    <div class="form-material floating">
                                        <select name="designation" id="designation" class="form-control">
                                            <option value="#">Select Designation</option>
                                            <option value="Professore">Professore</option>
                                            <option value="Astt.professore">Astt.Professore</option>
                                            <option value="Sr.Lecturer">Senior Lecturer</option>
                                            <option value="Lecturer">Lecturer</option>
                                            <option value="Jr.Lecturer">Jr.Lecturer</option>
                                        </select>
                                        <!-- <label for="material-textarea-small2">Faculty</label> -->
                                    </div>
                                </div>
                            </div>




                            
                            <div class="form-group row">
                                <div class="col-12">
                                    <div class="form-material floating">
                                        <input type="file" name="teacherImage" id="image">
                                        
                                    </div>
                                </div>
                            </div>
                            

                            <div class="form-group row">
                                <div class="col-md-9">
                                    <button type="submit" class="btn btn-alt-primary">Submit</button>
                                </div>
                            </div>
                        </form>



                    </div>
                </div>
                <!-- END Floating Labels -->
            </div>
        </div>
        <!-- END Material Design -->
    </div>
    <!-- END Page Content -->
</main>
<!-- END Main Container -->

@endsection