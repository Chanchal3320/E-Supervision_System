@extends('dashboard')

@section('title')

ESS || Teacher List

@endsection


@section('mainContent')


@include('admin.includes.sidebar')

<!-- Main Container -->
            <main id="main-container">

                <h3 style="text-align: center" class="text-success">
                    
                    {{Session::get('message')}}
                </h3>
                <!-- Page Content -->
                <div class="content">
                    <h2 class="content-heading">All Teacher List</h2>

                    <!-- Dynamic Table Full -->
                    <div class="block">
                        
                        <div class="block-content block-content-full">
                            <!-- DataTables init on table by adding .js-dataTable-full class, functionality initialized in js/pages/be_tables_datatables.js -->
                            <table class="table table-bordered table-striped table-vcenter js-dataTable-full">
                                <thead>
                                    <tr>
                                        <th class="text-center"></th>
                                        <th>Name</th>                                        
                                        <th class="d-none d-sm-table-cell">Email</th>
                                        <th class="d-none d-sm-table-cell">Faculty</th>
                                        <th class="d-none d-sm-table-cell" style="width: 15%;">Designation</th>
                                        <th class="text-center" style="width: 15%;">Profile</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                     $i = 1;

                                    ?>
                                    <tr>
                                        @foreach($teachers as $teacher)
                                        <td class="text-center">{{$i++}}</td>
                                        <td class="font-w600">{{$teacher->userName}}</td>
                                        <td class="d-none d-sm-table-cell">{{$teacher->email}}</td>
                                        <td class="font-w600">{{$teacher->faculty}}</td>
                                        <td class="d-none d-sm-table-cell">
                                            <span class="badge badge-success">{{$teacher->designation}}</span>
                                        </td>
                                        <td class="text-center">
                                            <a href="{{url('/viewProfile/'.$teacher->id)}}">
                                            <button type="button" class="btn btn-sm btn-secondary" data-toggle="tooltip" title="View Profile">
                                                <i class="fa fa-user"></i>
                                            </button>
                                            </a>
                                        </td>
                                    </tr>
                                    
                                    @endforeach
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- END Dynamic Table Full -->

                   

                   
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->


@endsection