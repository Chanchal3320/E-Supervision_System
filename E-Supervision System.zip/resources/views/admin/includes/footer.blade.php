<!-- Footer -->
            <footer id="page-footer" class="opacity-0">
                <div class="content py-20 font-size-xs clearfix">
                    <div class="float-right">
                        Developed <i class="fa fa-heart text-pulse"></i> by <a class="font-w600" href="#" target="_blank">DIU Student</a>
                    </div>
                    
                </div>
            </footer>
            <!-- END Footer -->