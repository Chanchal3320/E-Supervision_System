<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Counselling extends Model
{
    protected $primaryKey = 'counselling_id';
}
