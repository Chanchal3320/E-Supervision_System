<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FirstStudent extends Model
{
    protected $primaryKey = 'fStudent_id';
}
