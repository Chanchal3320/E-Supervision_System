<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SecondStudent extends Model
{
   protected $primaryKey = 'sStudent_id';
}
