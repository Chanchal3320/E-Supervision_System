<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Project;
use App\FirstStudent;
use App\SecondStudent;
use App\ThirdStudent;


class ProjectController extends Controller
{
    public function viewProjectInfo($project_id)
    {
    	$projectById = DB::table('projects')
  			->join('first_students','projects.fStudent_sId','=','first_students.fStudent_sId')
  			->join('second_students','projects.sStudent_sId','=','second_students.sStudent_sId')
  			->join('third_students','projects.tStudent_sId','=','third_students.tStudent_sId')
  			->select('projects.*','first_students.*','second_students.*','third_students.*')
  			->where('projects.project_id',$project_id)
            ->first();

  			return view('admin.student.viewProjectInfo',['projectById'=>$projectById]);
    }



      public function viewGroupDetails($project_id)
    {
      $detailsById = DB::table('projects')
        ->join('first_students','projects.fStudent_sId','=','first_students.fStudent_sId')
        ->join('second_students','projects.sStudent_sId','=','second_students.sStudent_sId')
        ->join('third_students','projects.tStudent_sId','=','third_students.tStudent_sId')
        ->select('projects.*','first_students.*','second_students.*','third_students.*')
        ->where('projects.project_id',$project_id)
        ->first();

        return view('frontEnd.Student.studentGroup.groupDetails',['detailsById'=>$detailsById]);
    }


    public function projectList()
    {
     $projects = Project::all();
     return view('frontEnd.Student.project.projectList',['projects'=>$projects]);
    }

    public function sprojectList()
      {
       $projects = Project::all();
       return view('frontEnd.supervisor.student.projectList',['projects'=>$projects]);
      }


      public function projectStatus($project_id)
      {
         $projectStatus = Project::where('project_id',$project_id)->first();

          $projectStatus->status = 0 ;
          $projectStatus->save();


          return redirect('/allProjectList');
      }

 public function statusProject($project_id)
      {
         $projectStatus = Project::where('project_id',$project_id)->first();

          $projectStatus->status = 0 ;
          $projectStatus->save();


          return redirect('/supervisor/allProjectList');
      }



         public function singleGroupDetails($project_id)
    {
        $detailsById = DB::table('projects')
        ->join('first_students','projects.fStudent_sId','=','first_students.fStudent_sId')
        ->join('second_students','projects.sStudent_sId','=','second_students.sStudent_sId')
        ->join('third_students','projects.tStudent_sId','=','third_students.tStudent_sId')
        ->select('projects.*','first_students.*','second_students.*','third_students.*')
        ->where('projects.project_id',$project_id)
        ->first();

        return view('admin.student.viewStudentGroup',['detailsById'=>$detailsById]);
    }



}
