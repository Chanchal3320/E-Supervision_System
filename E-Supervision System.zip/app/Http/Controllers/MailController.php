<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;
use App\Mail\SendMail;
use Auth;

class MailController extends Controller
{
    public function sendMail(Request $request)
    {
    	Mail::send(new SendMail());





    	return redirect()->back();
    }
}
