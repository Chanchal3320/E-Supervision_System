<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Counselling;
use Validator;

class CounsellingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {	
    	$counsellings = Counselling::all();
        return view('admin.supervisor.manageCounselling',['counsellings'=> $counsellings]);
    }


    public function addCounselling(Request $request)
    {
             $validator = Validator::make($request->all(), [
           
           'counselling_day' => 'required',
           'counselling_time' => 'required',
           
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }



    	 // dd($request->all());
    	$counselling = new Counselling();
    	$counselling->supervisor_id   = $request-> supervisor_id ;
    	$counselling->counselling_day  = $request->counselling_day ;
    	$counselling->counselling_time = $request->counselling_time ;

    	$counselling->save();

    	return redirect()->back();
    }



    public function deleteCounselling($counselling_id)
    {
       $counselling = Counselling::find($counselling_id);

       // echo $counselling;
        $counselling->delete();

       return redirect()->back();
    }


    public function firstCounselling()
    {
       return view('frontEnd.supervisor.supervisor.sCounselling');
    }



    public function saveFirstCounselling(Request $request)
    {
             $validator = Validator::make($request->all(), [
           
           'counselling_day' => 'required',
           'counselling_time' => 'required',
           
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }




        // dd($request->all());
        $counselling = new Counselling();
        $counselling->supervisor_id   = $request-> supervisor_id ;
        $counselling->counselling_day  = $request->counselling_day ;
        $counselling->counselling_time = $request->counselling_time ;

        $counselling->save();

        return redirect('/supervisor/allSupervisor')->with('message','All Information Save Successfully..!!');
    }

   
}
