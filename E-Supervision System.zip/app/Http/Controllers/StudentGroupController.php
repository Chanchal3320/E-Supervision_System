<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Project;
use App\FirstStudent;
use App\SecondStudent;
use App\ThirdStudent;
use App\StudentId;
use Session;
use Auth;
use Validator;


class StudentGroupController extends Controller
{
	/* ----- First Student Information Save Function -----*/
    public function index()
    {
    	return view('frontEnd.Student.studentGroup.addStudentGroup');
    }


    public function studentHome()
    {
        return view('frontEnd.student.homeStudent');
    }


 
   
    

    public function fStudentInfoAdd(Request $request)
    {   

         $validator = Validator::make($request->all(), [
            'fStudent_name'=>'required', 
           'fStudent_batch'=>'required', 
           'fStudent_sID'=>'required', 
           'fStudent_email'=>'required|email', 
           'fStudent_phone'=>'required', 
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }

      


        $fStudentIdTotal = $request->fStudent_batch."-"."15"."-".$request->fStudent_sID;

    	$firstStudent = new FirstStudent();
		$firstStudent->fStudent_name   = $request->fStudent_name ;
		$firstStudent->fStudent_sId    = $fStudentIdTotal ;
		$firstStudent->fStudent_email  = $request->fStudent_email;
		$firstStudent->fStudent_phone  = $request->fStudent_phone;
		$firstStudent->save();	

    	 $fStudentId = $firstStudent->fStudent_sId; 
    	 Session::put('fStudent_sId', $fStudentId); 

		


   	return redirect('/student/sStudentInfo')->with('message','First Student Information Save Successfully');

     
		
    }


    /* ----- Second Student Information Save Function -----*/

    public function sStudentInfo()
    {
    	return view('frontEnd.Student.studentGroup.secondStudent');
    }



        public function sStudentInfoAdd(Request $request)
    {
    	// dd($request->all());

        $validator = Validator::make($request->all(), [
            'sStudent_name'=>'required', 
           'sStudent_batch'=>'required', 
           'sStudent_sID'=>'required', 
           'sStudent_email'=>'required|email', 
           'sStudent_phone'=>'required', 
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }


        $sStudentIdTotal = $request->sStudent_batch."-"."15"."-".$request->sStudent_sID;
    	
    		$secondStudent = new SecondStudent();
    		$secondStudent->sStudent_name   = $request->sStudent_name ;
    		$secondStudent->sStudent_sId    = $sStudentIdTotal;
    		$secondStudent->sStudent_email  = $request->sStudent_email;
    		$secondStudent->sStudent_phone  = $request->sStudent_phone;    		
    		$secondStudent->save();    	

    	 $sStudentId = $secondStudent->sStudent_sId; 
    	 Session::put('sStudent_sId', $sStudentId);

    		

    	return redirect('/student/tStudentInfo')->with('message','Second Student Information Save Successfully');
    }



/* ----- Third Student Information Save Function -----*/

	public function tStudentInfo()
	{
		return view('frontEnd.Student.studentGroup.thirdStudent');
	}



   public function tStudentInfoAdd(Request $request)
    {
    	// dd($request->all());

         $validator = Validator::make($request->all(), [
            'tStudent_name'=>'required', 
           'tStudent_batch'=>'required', 
           'tStudent_sID'=>'required', 
           'tStudent_email'=>'required|email', 
           'tStudent_phone'=>'required', 
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }



        $tStudentIdTotal = $request->tStudent_batch."-"."15"."-".$request->tStudent_sID;
    		$thirdStudent = new ThirdStudent();

    		$thirdStudent->tStudent_name   = $request->tStudent_name;
    		$thirdStudent->tStudent_sId    = $tStudentIdTotal;
    		$thirdStudent->tStudent_email  = $request->tStudent_email;
    		$thirdStudent->tStudent_phone  = $request->tStudent_phone;
    		$thirdStudent->save();    

    	   $tStudentId = $thirdStudent->tStudent_sId;  	   

    	 Session::put('tStudent_sId', $tStudentId);
		

    	return redirect('/student/projectForm')->with('message','Third Student Information Save Successfully');
    }


    /*---- Project Information Save --------*/

      public function allProjectList()
    {
        $projects = Project::all();
    	return view('admin.student.projectDetails',['projects'=>$projects]);

	}

    public function addProjectInfo(Request $request) 
    {

         $validator = Validator::make($request->all(), [
            'project_name'=>'required', 
           'project_sector'=>'required', 
           'project_length'=>'required', 
            
           'project_details'=>'required', 
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }


    	// dd($request->all());

    	$project = new Project();    	
        $project->project_name     = $request-> project_name ;
    	$project->project_sector   = $request-> project_sector ;
    	$project->project_length   = $request-> project_length ;
    	$project->project_details  = $request-> project_details ;

    	$project->fStudent_sId  = Session::get('fStudent_sId') ; 
    	$project->sStudent_sId  = Session::get('sStudent_sId') ; 
    	$project->tStudent_sId  = Session::get('tStudent_sId') ; 
    	$project->save();
    	return redirect('/student/listStudentGroup')->with('message','Project Details Save Successfully..!!');
    }



  public function listStudentGroup()
  {
	$studentGroupList = DB::table('projects')
		->join('first_students','projects.fStudent_sId','=','first_students.fStudent_sId')
		->join('second_students','projects.sStudent_sId','=','second_students.sStudent_sId')
		->join('third_students','projects.tStudent_sId','=','third_students.tStudent_sId')
		->select('projects.*','first_students.*','second_students.*','third_students.*')
		->get();

		return view('admin.student.listOfStudentGroup',['studentGroupList'=> $studentGroupList]);
  }


  public function viewStudentGroup()
  {
    $studentGroupList = DB::table('projects')
        ->join('first_students','projects.fStudent_sId','=','first_students.fStudent_sId')
        ->join('second_students','projects.sStudent_sId','=','second_students.sStudent_sId')
        ->join('third_students','projects.tStudent_sId','=','third_students.tStudent_sId')
        ->select('projects.*','first_students.*','second_students.*','third_students.*')
        ->get();

        return view('frontEnd.Student.studentGroup.viewGroupList',['studentGroupList'=> $studentGroupList]);
  }

 public function sviewStudentGroup()
  {
    $studentGroupList = DB::table('projects')
        ->join('first_students','projects.fStudent_sId','=','first_students.fStudent_sId')
        ->join('second_students','projects.sStudent_sId','=','second_students.sStudent_sId')
        ->join('third_students','projects.tStudent_sId','=','third_students.tStudent_sId')
        ->select('projects.*','first_students.*','second_students.*','third_students.*')
        ->get();

        return view('frontEnd.supervisor.student.studentList',['studentGroupList'=> $studentGroupList]);
  }


  public function formProject()
  {
      return view('frontEnd.Student.project.formProject');
  }



  public function viewProfile()
  {
     $studentProfile = DB::table('users')
                        
                        ->where('users.email', Auth::user()->email)
                        ->select('users.*')
                        ->first();

              return view('frontEnd.Student.profile',['studentProfile'=>$studentProfile]);
  }





  

}
