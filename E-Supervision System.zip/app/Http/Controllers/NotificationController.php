<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Notification;
use Auth;
use DB;


class NotificationController extends Controller
{
    public function sendRequest($id)
    {
   
    	$sendRequest = Notification::create([

    		'requester' => Auth::user()->id,
    		'user_requested' => $id,
    		'status' => 0,
    		

    	]);

    	// if ($sendRequest) {
    	// 	return $sendRequest;
    	// }

    	 return redirect()->back();

    }


    public function confirmRequest($id)  
    {
    
    	$uId = Auth::user()->id;


    	$checkRequest = Notification::where('requester',$id)
    				->where('user_requested',$uId)
    				->first();

    		if ($checkRequest) {
    			

    			$checkRequest->status = 1;
    			$checkRequest->save();


    			return redirect()->back();

    		}

    		else{
    			echo "Fails";
    		}
    }


    public function deleteRequest($id)
    {
    	$uId = Auth::user()->id;


    	$deleteRequest = Notification::where('requester',$id)
    				->where('user_requested',$uId)
    				->first();

    		if ($deleteRequest) {
    			
    			$deleteRequest->delete();
    			


    			return redirect()->back();

    		}

    		else{
    			echo "Fails";
    		}
    }






    
}
