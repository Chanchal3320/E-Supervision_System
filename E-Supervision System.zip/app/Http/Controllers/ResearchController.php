<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Research;
use Session;
use App\Supervisor;
use Auth;



class ResearchController extends Controller 
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       return view('admin.supervisor.showResearch');
    }

   

   


    public function store(Request $request)
    {
         $validator = Validator::make($request->all(), [
           
           'research_topics' => 'required',           
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }



        $research = new Research();
        $research-> supervisor_id    =$request->supervisor_id;
        $research-> research_topics  = $request->research_topics;
        $research -> save();

        return redirect()->back();


    }



    public function delete($research_id)
    {
        $research = Research::find($research_id);
        $research->delete();

       return redirect()->back();
    }



    public function firstResearch()
    {
        return view('frontEnd.supervisor.supervisor.sResearch');
    }


    public function saveFirstResearch( Request $request)
    {
         $validator = Validator::make($request->all(), [
           
           'research_topics' => 'required',           
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }

        
        $research = new Research();
        $research-> supervisor_id    =$request->supervisor_id;
        $research-> research_topics  = $request->research_topics;
        $research -> save();

        // dd($request->all());

        return redirect('/supervisor/firstCounselling')->with('message','Research Topics Save Successfully..!!');
    }
    



}
