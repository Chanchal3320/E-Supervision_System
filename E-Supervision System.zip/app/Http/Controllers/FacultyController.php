<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Faculty;
use App\Department;
use  Validator;

class FacultyController extends Controller
{
    public function index()
    {
        $faculties = Faculty::all();
    	return view('admin.faculty.addFaculty',['faculties'=>$faculties]);
    }





    public function addFaculty(Request $request)
    {
       $validator = Validator::make($request->all(), [
           
           'counselling_day' => 'required',
           'counselling_time' => 'required',
           
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }



    	$faculty = new Faculty();
    	$faculty->faculty_name = $request->faculty_name;
    	$faculty->save();

    	return redirect()->back()->with('message','Faculty Name Save Successfully..!!');
    }

    

    public function editFaculty(Request $request )
    {
        // dd($request->all());
        $faculty =  Faculty::find($request->faculty_id);

        $faculty->faculty_name = $request->faculty_name;
        $faculty->save();

        return redirect()->back()->with('message','Faculty Name Update Successfully..!!');
    }



    public function allDepartmentList()
    {
       
          
        $departments = Department::all();
        return view('admin.faculty.allDepartment',['departments'=>$departments]);
    }


    public function saveDepartmentInfo(Request $request)
    {
         $validator = Validator::make($request->all(), [
           
           'department_name' => 'required',           
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }

        $department = new Department();
        $department->department_name = $request->department_name;
        $department->save();

        return redirect()->back()->with('message','Department Info Save Successfully..!!');
    }


    public function editDepartmentInfo(Request $request)
    {
        $department = Department::find($request->department_id);
        $department->department_name = $request->department_name;
        $department->save();

        return redirect()->back()->with('message','Department Info Update Successfully..!!');
    }



    public function facultyList()
    {
        $faculties = Faculty::all();
        return view('frontEnd.supervisor.faculty.facultyList',['faculties'=>$faculties]);
    }


    public function departmentList()
    {
        $departments = Department::all();
        return view('frontEnd.supervisor.department.departmentList',['departments'=>$departments]);
    }
}
