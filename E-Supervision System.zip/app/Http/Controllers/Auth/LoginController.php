<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use User;
use Auth;

class LoginController extends Controller
{
   



    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
   // protected $redirectTo = '/';  

    /**
     * Create a new controller instance.
     *
     * @return void
     */
   
    protected function authenticated(){

        if (Auth::User()->isAdmin()) {
            return redirect('/admin');
        }

        elseif (Auth::User()->isSupervisor()) {
           return redirect('/supervisor');
        }

        elseif (Auth::User()->isStudent()) {
            return redirect('/student');
        }
        else{
            return redirect('/');
        }
    }








    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }





}
