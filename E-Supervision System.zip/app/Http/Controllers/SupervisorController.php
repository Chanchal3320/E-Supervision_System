<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Supervisor;
use Session;
use DB;
use App\User;
use Auth;


class SupervisorController extends Controller
{
    public function index()
    {
    	return view('frontEnd.supervisor.supervisor.addSupervisor'); 
    }

    public function supervisorHome()
    {
      return view('frontEnd.supervisor.homeSupervisor'); 
    }



     
    public function addSupervisorInfo(Request $request)
    {

          $validator = Validator::make($request->all(), [
            'supervisor_firstName' => 'required',
           'supervisor_lastName' => 'required',
           'supervisor_email' => 'required|email',
           'supervisor_phone' => 'required',
           'supervisor_designation' => 'required',
           'supervisor_department' => 'required',
           'supervisor_image' => 'required', 
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }

       

      




       $supervisorImage = $request->file('supervisor_image');
       // echo '<pre>';
       // print_r($supervisorImage);

       $imageName= $supervisorImage->getClientOriginalName();
       // echo $imagetName;

       $uploadPath='supervisorImage/';


       $supervisorImage->move($uploadPath,$imageName);
       $imageURL=$uploadPath.$imageName;
       $this->saveSupervisorInfo($request,$imageURL);


       
       return redirect('/supervisor/firstResearch')->with('message','Supervisor Info Save Successfully..!!');
   }
 protected function saveSupervisorInfo($request,$imageURL) 
    {
        $supervisor = new Supervisor();
        $supervisor->supervisor_firstName      = $request-> supervisor_firstName ;  
        $supervisor->supervisor_lastName       = $request-> supervisor_lastName;
        $supervisor->email                     = $request-> supervisor_email;
        $supervisor->supervisor_image          = $imageURL;
        $supervisor->supervisor_designation    = $request->supervisor_designation;
        $supervisor->supervisor_department     = $request->supervisor_department;
        $supervisor->supervisor_phone          = $request->supervisor_phone;
       
        $supervisor->save();

         $supervisor_id = $supervisor->supervisor_id;

        Session::put('supervisor_id',$supervisor_id);


       

    }
      

      public function manageSupervisor()
      {
          $supervisors = Supervisor::all();
          return view('admin.supervisor.manageSupervisor',['supervisors'=>$supervisors]);
      }



      public function viewProfile($supervisor_id)
      {
        $profileById = DB::table('supervisors')
               ->join('researches','supervisors.supervisor_id','=','researches.supervisor_id')
              ->join('counsellings','supervisors.supervisor_id','=','counsellings.supervisor_id')

              ->select('supervisors.*', 'researches.*', 'counsellings.*')
              ->where('supervisors.supervisor_id',$supervisor_id)
              ->first();




         return view('admin.supervisor.viewSupervisorProfile',['profile'=> $profileById]);
      }



       public function SupervisorEditForm($supervisor_id)
      {

        $supervisorInfos = Supervisor::where('supervisor_id',$supervisor_id)->first();


        return view('frontEnd.supervisor.supervisor.editProfile',['supervisorInfos' => $supervisorInfos]);
      }



      public function allSupervisortList()
      {
         $supervisors = DB::table('supervisors')
              ->join('users','supervisors.email','=','users.email')
              ->select('supervisors.*','users.*')
              ->get();

         


          return view('frontEnd.Student.supervisor.supervisorList',['supervisors'=>$supervisors]);
      }


       public function viewSupervisorProfile($supervisor_id)
      {
        $profileById = DB::table('supervisors')
               ->join('researches','supervisors.supervisor_id','=','researches.supervisor_id')
              ->join('counsellings','supervisors.supervisor_id','=','counsellings.supervisor_id')
              ->select('supervisors.*', 'researches.*', 'counsellings.*')
              ->where('supervisors.supervisor_id',$supervisor_id)
              ->first();




         return view('frontEnd.Student.supervisor.viewProfile',['studentprofile'=> $profileById]);
      }



      public function supervisorList()
      {
        $supervisors = Supervisor::all();
          return view('frontEnd.supervisor.supervisor.supervisorList',['supervisors'=>$supervisors]);
      }


      public function singleSupervisorProfile($supervisor_id)
      {
         $profileById = DB::table('supervisors')
               ->join('researches','supervisors.supervisor_id','=','researches.supervisor_id')
              ->join('counsellings','supervisors.supervisor_id','=','counsellings.supervisor_id')

              ->select('supervisors.*', 'researches.*', 'counsellings.*')
              ->where('supervisors.supervisor_id',$supervisor_id)
              ->first();

         return view('frontEnd.supervisor.supervisor.viewProfile',['profileById'=> $profileById]);
      }



     






      public function SupervisorUpdateInfo(Request $request)
      {
         $imageURL= $this->imageExistStatus($request);  
        $this->updateSupervisorInfo($request,$imageURL);

        return redirect('/supervisor/allSupervisor')->with('message','Supervisor Info Update Successfullty..!');
      }


      private function imageExistStatus($request)
      { 
    $supervisorById = Supervisor::where('supervisor_id',$request->supervisor_id)->first();
    
    $supervisorImage = $request->file('supervisor_image');

    if ($supervisorImage) {
        $oldImageURL = $supervisorById->supervisor_image ;

        unlink($oldImageURL);
        $imageName= $supervisorImage->getClientOriginalName();
        //echo $imageName;

         $uploadPath='supervisorImage/';


         $supervisorImage->move($uploadPath,$imageName);
          $imageURL=$uploadPath.$imageName;

         }

         else {
            $imageURL = $supervisorById->supervisor_image;

         }
         return $imageURL;
      }
      protected function updateSupervisorInfo($request,$imageURL) 
    {
        $supervisor =Supervisor::find($request->supervisor_id);
          
        $supervisor->supervisor_firstName      = $request->supervisor_firstName ;  
        $supervisor->supervisor_lastName       = $request->supervisor_lastName;       
        $supervisor->supervisor_image          = $imageURL;
        $supervisor->supervisor_designation    = $request->supervisor_designation;
        $supervisor->supervisor_department     = $request->supervisor_department;
        $supervisor->supervisor_phone          = $request->supervisor_phone;       
        $supervisor->save();
    }


    public function editProfileView($supervisor_id)
    {
      $supervisorInfos = Supervisor::where('supervisor_id',$supervisor_id)->first();


        return view('admin.supervisor.editProfileView',['supervisorInfos' => $supervisorInfos]);
    
    }


  public function editProfile(Request $request)
      {
         $imageURL= $this->imageExistStatus($request);  
        $this->updateSupervisorInfo($request,$imageURL);

        return redirect('/supervisor/allSupervisor')->with('message','Supervisor Info Update Successfullty..!');
      }


      

      public function profile()
      {
            $profileView = DB::table('supervisors')
                        ->join('users','supervisors.email','=','users.email')
                        ->where('supervisors.email', Auth::user()->email)
                        ->select('supervisors.*')
                        ->first();

              return view('frontEnd.supervisor.profile.profile',['profileView'=>$profileView]);
      }




      public function sViewGroupDetails($project_id)
      {
        $studentGroupDetails = DB::table('projects')
        ->join('first_students','projects.fStudent_sId','=','first_students.fStudent_sId')
        ->join('second_students','projects.sStudent_sId','=','second_students.sStudent_sId')
        ->join('third_students','projects.tStudent_sId','=','third_students.tStudent_sId')
        ->select('projects.*','first_students.*','second_students.*','third_students.*')
        ->where('projects.project_id',$project_id)
        ->first();


        return view('frontEnd.supervisor.student.groupDetails',['studentGroupDetails'=>$studentGroupDetails]);

      }

      

    

     

    
}
