<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Research extends Model
{
     protected $fillable = [
        'supervisor_id','research_topics'
    ];


    protected $primaryKey = 'research_id';
}
