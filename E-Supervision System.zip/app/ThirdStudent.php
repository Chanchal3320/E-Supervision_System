<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ThirdStudent extends Model
{
    protected $primaryKey = 'tStudent_id';
}
