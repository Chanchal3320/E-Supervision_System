<?php $__env->startSection('title'); ?>

ESS || Supervisor Home
 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>
<?php echo $__env->make('frontEnd.supervisor.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>




 <!-- Main Container -->
<main id="main-container" class="supervisor_main">
    <!-- Hero -->
    <div class="bg-image bg-image-bottom" style="background-image: url('/frontEnd/img/photos/photo34@2x.jpg');">
        <div class="bg-primary-dark-op">
            <div class="content content-top text-center overflow-hidden">
                <div class="pt-50 pb-20">
                    
                    <h2 class="h4 font-w400 text-white-op invisible" data-toggle="appear" data-class="animated fadeInUp">Welcome to your <?php echo e(Auth::user()->role); ?> panel!</h2>
                </div>
            </div>
        </div>
    </div>
    <!-- END Hero -->


    <?php 
        $totalStudent = DB::table('users')
                    ->where('role','student')
                    ->count();
        $totalSupervisor = DB::table('users')
                    ->where('role','supervisor')
                    ->count();

        $totalProject = DB::table('projects')
                       ->count();

        $totalDepartment = DB::table('departments')
                               ->count();

    ?>

    <!-- Page Content -->
    <div class="content">
        <div class="row invisible" data-toggle="appear">
            <!-- Row #1 -->
            <div class="col-6 col-xl-3">
                <a class="block block-link-pop text-right bg-primary" href="javascript:void(0)">
                    <div class="block-content block-content-full clearfix border-black-op-b border-3x">
                        <div class="float-left mt-10 d-none d-sm-block">
                            <i class="si si-bar-chart fa-3x text-primary-light"></i>
                        </div>
                        <div class="font-size-h3 font-w600 text-white" data-toggle="countTo" data-speed="1000" data-to="<?php echo e($totalStudent); ?>">0</div>
                        <div class="font-size-sm font-w600 text-uppercase text-white-op">Total Student</div>
                    </div>
                </a>
            </div>
            <div class="col-6 col-xl-3">
                <a class="block block-link-pop text-right bg-earth" href="javascript:void(0)">
                    <div class="block-content block-content-full clearfix border-black-op-b border-3x">
                        <div class="float-left mt-10 d-none d-sm-block">
                            <i class="si si-trophy fa-3x text-earth-light"></i>
                        </div>
                        <div class="font-size-h3 font-w600 text-white"><span data-toggle="countTo" data-speed="1000" data-to="<?php echo e($totalSupervisor); ?>">0</span></div>
                        <div class="font-size-sm font-w600 text-uppercase text-white-op">Total Supervisor</div>
                    </div>
                </a>
            </div>
            <div class="col-6 col-xl-3">
                <a class="block block-link-pop text-right bg-elegance" href="javascript:void(0)">
                    <div class="block-content block-content-full clearfix border-black-op-b border-3x">
                        <div class="float-left mt-10 d-none d-sm-block">
                            <i class="si si-envelope-letter fa-3x text-elegance-light"></i>
                        </div>
                        <div class="font-size-h3 font-w600 text-white" data-toggle="countTo" data-speed="1000" data-to="<?php echo e($totalProject); ?>">0</div>
                        <div class="font-size-sm font-w600 text-uppercase text-white-op">Total Project</div>
                    </div>
                </a>
            </div>
            <div class="col-6 col-xl-3">
                <a class="block block-link-pop text-right bg-corporate" href="javascript:void(0)">
                    <div class="block-content block-content-full clearfix border-black-op-b border-3x">
                        <div class="float-left mt-10 d-none d-sm-block">
                            <i class="si si-fire fa-3x text-corporate-light"></i>
                        </div>
                        <div class="font-size-h3 font-w600 text-white" data-toggle="countTo" data-speed="1000" data-to="<?php echo e($totalDepartment); ?>">0</div>
                        <div class="font-size-sm font-w600 text-uppercase text-white-op">Total Department</div>
                    </div>
                </a>
            </div>
            <!-- END Row #1 -->
        </div>
        <div class="row invisible" data-toggle="appear">
          
       
        
    </div>
    <!-- END Page Content -->
</main>
<!-- END Main Container -->




<?php $__env->stopSection(); ?>





<?php echo $__env->make('frontEnd.supervisor.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>