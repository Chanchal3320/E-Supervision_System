 <link rel="shortcut icon" href="<?php echo e(asset('backEnd/img/favicons/favicon.png')); ?>">
        <link rel="icon" type="image/png" sizes="192x192" href="<?php echo e(asset('backEnd/img/favicons/favicon-192x192.png')); ?>">
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('backEnd/img/favicons/apple-touch-icon-180x180.png')); ?>">
        <!-- END Icons -->

        <!-- Stylesheets -->
        <!-- Codebase framework -->
        <link rel="stylesheet" id="css-main" href="<?php echo e(asset('backEnd/css/codebase.min.css')); ?>">
        <link rel="stylesheet" id="css-main" href="<?php echo e(asset('backEnd/css/material-bootstrap-wizard.css')); ?>">

 <!-- Page JS Plugins CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('backEnd/js/plugins/datatables/dataTables.bootstrap4.min.css')); ?>">

        <link href="https://fonts.googleapis.com/css?family=Spirax" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Arvo" rel="stylesheet"> 

        <!--     Fonts and icons     -->
	<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />


  
       <link href="<?php echo e(asset('backEnd/datatables/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">

      
     <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    





     <script src="<?php echo e(asset('backEnd/bootstrap/js/ie-emulation-modes-warning.js')); ?>"></script>