<?php $__env->startSection('title'); ?>

ESS || Home

<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>


   <?php 
        $totalStudent = DB::table('users')
                    ->where('role','student')
                    ->count();
        $totalSupervisor = DB::table('users')
                    ->where('role','supervisor')
                    ->count();

        $totalProject = DB::table('projects')
                       ->count();

        $totalDepartment = DB::table('departments')
                               ->count();

       $totalFaculty = DB::table('faculties')
                    ->count();

        $totalUser = DB::table('users')
                    ->count();

    ?>
<!-- Main Container -->
<main id="main-container">
    <!-- Page Content -->
    <div class="content">
        <div class="row gutters-tiny invisible" data-toggle="appear">
            <!-- Row #1 -->
            <div class="col-6 col-xl-3">
                <a class="block block-link-shadow text-right" href="javascript:void(0)">
                    <div class="block-content block-content-full clearfix">
                        <div class="float-left mt-10 d-none d-sm-block">
                            <i class="si si-bag fa-3x text-body-bg-dark"></i>
                        </div>
                        <div class="font-size-h3 font-w600" data-toggle="countTo" data-speed="1000" data-to="<?php echo e($totalStudent); ?>">0</div>
                        <div class="font-size-sm font-w600 text-uppercase text-muted">Total Student</div>
                    </div>
                </a>
            </div>
            <div class="col-6 col-xl-3">
                <a class="block block-link-shadow text-right" href="javascript:void(0)">
                    <div class="block-content block-content-full clearfix">
                        <div class="float-left mt-10 d-none d-sm-block">
                            <i class="si si-wallet fa-3x text-body-bg-dark"></i>
                        </div>
                        <div class="font-size-h3 font-w600"><span data-toggle="countTo" data-speed="1000" data-to="<?php echo e($totalSupervisor); ?>">0</span></div>
                        <div class="font-size-sm font-w600 text-uppercase text-muted">Total Supervisor</div>
                    </div>
                </a>
            </div>
            <div class="col-6 col-xl-3">
                <a class="block block-link-shadow text-right" href="javascript:void(0)">
                    <div class="block-content block-content-full clearfix">
                        <div class="float-left mt-10 d-none d-sm-block">
                            <i class="si si-envelope-open fa-3x text-body-bg-dark"></i>
                        </div>
                        <div class="font-size-h3 font-w600" data-toggle="countTo" data-speed="1000" data-to="<?php echo e($totalFaculty); ?>">0</div>
                        <div class="font-size-sm font-w600 text-uppercase text-muted">Total Faculty</div>
                    </div>
                </a>
            </div>
            <div class="col-6 col-xl-3">
                <a class="block block-link-shadow text-right" href="javascript:void(0)">
                    <div class="block-content block-content-full clearfix">
                        <div class="float-left mt-10 d-none d-sm-block">
                            <i class="si si-users fa-3x text-body-bg-dark"></i>
                        </div>
                        <div class="font-size-h3 font-w600" data-toggle="countTo" data-speed="1000" data-to="<?php echo e($totalDepartment); ?>">0</div>
                        <div class="font-size-sm font-w600 text-uppercase text-muted">Total Department</div>
                    </div>
                </a>
            </div>
            <!-- END Row #1 -->
        </div>
        
        
        <div class="row gutters-tiny invisible" data-toggle="appear">
            <!-- Row #4 -->
            <div class="col-md-6">
                <a class="block block-link-shadow overflow-hidden" href="javascript:void(0)">
                    <div class="block-content block-content-full">
                        <i class="si si-briefcase fa-2x text-body-bg-dark"></i>
                        <div class="row py-20">
                            <div class="col-6 text-right border-r">
                                <div class="invisible" data-toggle="appear" data-class="animated fadeInLeft">
                                    <div class="font-size-h3 font-w600"><?php echo e($totalProject); ?></div>
                                    <div class="font-size-sm font-w600 text-uppercase text-muted">Total Projects</div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="invisible" data-toggle="appear" data-class="animated fadeInRight">
                                    <div class="font-size-h3 font-w600">2</div>
                                    <div class="font-size-sm font-w600 text-uppercase text-muted">Active</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-6">
                <a class="block block-link-shadow overflow-hidden" href="javascript:void(0)">
                    <div class="block-content block-content-full">
                        <div class="text-right">
                            <i class="si si-users fa-2x text-body-bg-dark"></i>
                        </div>
                        <div class="row py-20">
                            <div class="col-6 text-right border-r">
                                <div class="invisible" data-toggle="appear" data-class="animated fadeInLeft">
                                    <div class="font-size-h3 font-w600 text-info"><?php echo e($totalUser); ?></div>
                                    <div class="font-size-sm font-w600 text-uppercase text-muted">Accounts</div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="invisible" data-toggle="appear" data-class="animated fadeInRight">
                                    <div class="font-size-h3 font-w600 text-success">97%</div>
                                    <div class="font-size-sm font-w600 text-uppercase text-muted">Active</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <!-- END Row #4 -->
        </div>
    
    </div>
    <!-- END Page Content -->
</main>
<!-- END Main Container -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>