<?php $__env->startSection('title'); ?>

SIS || Add Supervisor
 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>


<?php echo $__env->make('admin.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Main Container -->
<main id="main-container">

        
    <h3 style="text-align: center" class="text-success">
        
        <?php echo e(Session::get('message')); ?>

    </h3>

    <!-- Page Content -->
    <div class="content">
        <!-- Material Design -->
        <h2 class="content-heading">ADD Supervisor INFORMATION</h2>  
            <div class="row">
                   
               <!--  <div class="Research">
                    <a href="">
                        <button  class="btn btn-sm btn-alt-warning" >
                         Research Topics
                        </button> 
                    </a>
                </div>

                <div class="Counselling">
                    <a href=""><button class="btn btn-sm btn-alt-success" >
                         Counselling Time
                    </button></a>
                </div> -->
          
                <div class="col-md-8 offset-md-2">

                     <form  method="post" action="<?php echo e(url('/addSupervisorInfo')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                            <div class="block">
                                
                                <div class="block-content">
                                    <div class="form-group row">
                                        <div class="col-md-9">
                                            <div class="form-material floating">
                                                <input type="text" class="form-control" id="material-text2" name="supervisor_firstName">
                                                <label for="material-text2">First Name</label>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="form-group row">
                                        <div class="col-md-9">
                                            <div class="form-material floating">
                                                <input type="text" class="form-control" id="material-text2" name="supervisor_lastName">
                                                <label for="material-text2">Last Name</label>
                                            </div>
                                        </div>
                                    </div>



                                    <div class="form-group row">
                                        <div class="col-md-9">
                                            <div class="form-material floating">
                                                <input type="email" class="form-control" id="material-text2" name="supervisor_email">
                                                <label for="material-text2">Email</label>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="form-group row">
                                        <div class="col-md-9">
                                            <div class="form-material floating">
                                                <input type="text" class="form-control" id="material-text2" name="supervisor_phone">
                                                <label for="material-text2">Phone</label>
                                            </div>
                                        </div>
                                    </div>



                                    <div class="form-group row">
                                        <div class="col-md-9">
                                            <div class="form-material floating">
                                                <input type="text" class="form-control" id="material-text2" name="supervisor_designation">
                                                <label for="material-text2">Designation</label>
                                            </div>
                                        </div>
                                    </div> 



                                    <div class="form-group row">
                                        <div class="col-md-9">
                                            <div class="form-material floating">
                                                <input type="text" class="form-control" id="material-text2" name="supervisor_department">
                                                <label for="material-text2">Department</label>
                                            </div>
                                        </div>
                                    </div>


                                     


                                 

                                    <h5>Image</h5>
                                    <input type="file" name="supervisor_image" id="">


                                    

                                   

                                    
                                    

                                  

                                    <div class="block-options">
                                        <button class="btn btn-sm btn-alt-primary" type="submit">
                                            <i class="fa fa-check"></i> Submit
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>





                   
                </div> <!-- wizard container -->
            </div>



    </div>
        <!-- END Material Design -->
   
</main>
<!-- END Main Container -->

<?php $__env->stopSection(); ?>




                            
<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>