<?php $__env->startSection('title'); ?>

ESS || Student Group Details

<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>


<?php echo $__env->make('frontEnd.Student.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Main Container -->
            <main id="main-container">

                

                <!-- Page Content -->
                <div class="content">
                    <h2 class="content-heading">All Student Group List</h2>

                    <!-- Dynamic Table Full -->
                    <div class="block">
                        
                        <div class="block-content block-content-full">
                            <!-- DataTables init on table by adding .js-dataTable-full class, functionality initialized in js/pages/be_tables_datatables.js -->
                            <table class="table table-bordered table-dark  table-vcenter js-dataTable-full">
                             <thead>
                                 <tr>
                                     <th class="text-center"s>Title</th>
                                     <th class="text-center" colspan="3">Details</th>
                                 </tr>
                             </thead>
                                
                               
                                <tbody>
                                  <tr >
                                      <th rowspan="3"> Student Name</th>
                                      <td><strong>Name:</strong> <?php echo e($detailsById->fStudent_name); ?></td>
                                      <td><strong>ID:</strong> <?php echo e($detailsById->fStudent_sID); ?></td>
                                      <td><strong>Email:</strong> <?php echo e($detailsById->fStudent_email); ?></td>
                                      <td><strong>Mobile:</strong> <?php echo e($detailsById->fStudent_phone); ?></td>
                                      
                                  </tr> 

                                  <tr>
                                     
                                      <td><strong>Name:</strong> <?php echo e($detailsById->sStudent_name); ?></td>
                                      <td><strong>ID:</strong> <?php echo e($detailsById->sStudent_sID); ?></td>
                                      <td><strong>Email:</strong> <?php echo e($detailsById->sStudent_email); ?></td>
                                      <td><strong>Mobile:</strong> <?php echo e($detailsById->sStudent_phone); ?></td>
                                      
                                  </tr>
                                    <tr>
                                      
                                      <td><strong>Name:</strong> <?php echo e($detailsById->tStudent_name); ?></td>
                                      <td><strong>ID:</strong> <?php echo e($detailsById->tStudent_sID); ?></td>
                                      <td><strong>Email:</strong> <?php echo e($detailsById->tStudent_email); ?></td>
                                      <td><strong>Mobile:</strong> <?php echo e($detailsById->tStudent_phone); ?></td>
                                      
                                  </tr>

                                  <tr>
                                      <th>Project Name</th>
                                      <td class="text-center"><?php echo e($detailsById->project_name); ?></td>
                                  </tr>


                                  <tr>
                                      <th>Project Length</th>
                                      <td class="text-center"><?php echo e($detailsById->project_length); ?></td>
                                  </tr>
                                 <tr>
                                      <th>Project Description</th>
                                      <td class="text-center"><?php echo e($detailsById->project_details); ?></td>
                                  </tr>

                                   <tr>
                                      <th>Status</th>

                                      <?php 
                                      if ($detailsById->status == 1) {
                                        ?>
                                          <td class="text-center " id="btnActiveS">Active</td>

                                        <?php
                                      }else{
                                        ?>

                                         <td class="text-center" id="btnCompleted">Completed</td>


                                        <?php 
                                      }
                                      ?>
                                      
                                  </tr>




                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- END Dynamic Table Full -->

                   

                   
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.Student.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>