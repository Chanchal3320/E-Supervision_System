<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>

	Welcome to <?php echo e($msg); ?>

	
</body>
</html>






