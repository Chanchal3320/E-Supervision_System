<!-- Codebase Core JS -->
        <script src="<?php echo e(asset('backEnd/js/core/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backEnd/js/core/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backEnd/js/core/jquery.slimscroll.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backEnd/js/core/jquery.scrollLock.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backEnd/js/core/jquery.appear.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backEnd/js/core/jquery.countTo.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backEnd/js/core/js.cookie.min.j')); ?>s"></script>
        <script src="<?php echo e(asset('backEnd/js/codebase.js')); ?>"></script>
        <script src="<?php echo e(asset('backEnd/js/jquery.bootstrap.js')); ?>"></script>
        <script src="<?php echo e(asset('backEnd/js/jquery.validate.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backEnd/js/material-bootstrap-wizard.js')); ?>"></script>


        <!-- Page JS Plugins -->
        <script src="<?php echo e(asset('backEnd/js/plugins/chartjs/Chart.bundle.min.js')); ?>"></script>

        <!-- Page JS Code -->
        <script src="<?php echo e(asset('backEnd/js/pages/be_pages_dashboard.js')); ?>"></script>


        <!-- Page JS Plugins -->
        <script src="<?php echo e(asset('backEnd/js/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backEnd/js/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

        <!-- Page JS Code -->
        <script src="<?php echo e(asset('backEnd/js/pages/be_tables_datatables.js')); ?>"></script>
        <script src="<?php echo e(asset('backEnd/js/multi-step-form.js')); ?>"></script>

        
    <script src="<?php echo e(asset('backEnd/validator/validator.min.js')); ?>"></script>

      
    <script src="<?php echo e(asset('backEnd/dataTables/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backEnd/dataTables/js/dataTables.bootstrap.min.js')); ?>"></script>



 <script>

      $('#edit_faculty').on('show.bs.modal', function (event) {

      var button = $(event.relatedTarget) 
       
      var faculty_name = button.data('faculty_name') 
      var faculty_id = button.data('faculty_id') 
      var modal = $(this)

      
      modal.find('.modal-body #faculty_id').val(faculty_id);
      modal.find('.modal-body #faculty_name').val(faculty_name);
})


         $('#edit_department').on('show.bs.modal', function (event) {

      var button = $(event.relatedTarget) 
       
      var department_name = button.data('department_name') 
      var department_id = button.data('department_id') 
      var modal = $(this)

      
      modal.find('.modal-body #department_id').val(department_id);
      modal.find('.modal-body #department_name').val(department_name);
})

  </script>
