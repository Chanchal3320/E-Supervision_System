<?php $__env->startSection('title'); ?>

SIS || Add Student Information
 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>


<?php echo $__env->make('admin.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Main Container -->
<main id="main-container">

        
    <h3 style="text-align: center" class="text-success">
        
        <?php echo e(Session::get('message')); ?>

    </h3>

    <!-- Page Content -->
    <div class="content">
        <!-- Material Design -->
        <h2 class="content-heading">ADD STUDENT INFORMATION</h2>  
            <div class="row">
                    <div class="col-md-8 offset-md-2 ">
                        <!-- Floating Labels -->
                        <div class="block">
                            
                            <div class="block-content">
                                <form method="post" action="<?php echo e(url('/tStudentInfo')); ?>">
                                    <?php echo csrf_field(); ?>
                                        <div class="block">
                                            <div class="block-header block-header-default">
                                                <h3 class="block-title">Third Student Information</h3>
                                                
                                            </div>
                                            <div class="block-content">
                                                <div class="form-group row">
                                                    <div class="col-md-9">
                                                        <div class="form-material floating">
                                                            <input type="text" class="form-control" id="material-text2" name="tStudent_name">
                                                            <label for="material-text2">Name</label>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <div class="col-md-9">
                                                        <div class="form-material floating">
                                                            <input type="text" class="form-control" id="material-text2" name="tStudent_sID">
                                                            <label for="material-text2">Student ID</label>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <div class="col-md-9">
                                                        <div class="form-material floating">
                                                            <input type="text" class="form-control" id="material-text2" name="tStudent_email">
                                                            <label for="material-text2">Email</label>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <div class="col-md-9">
                                                        <div class="form-material floating">
                                                            <input type="text" class="form-control" id="material-text2" name="tStudent_phone">
                                                            <label for="material-text2">Phone</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="block-options">
                                                    <button class="btn btn-sm btn-alt-primary" type="submit">
                                                        <i class="fa fa-check"></i> Submit
                                                    </button>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                            </div>
                        </div>
                        <!-- END Floating Labels -->
                    </div>
                 




                   
                </div> <!-- wizard container -->
            </div>



    </div>
        <!-- END Material Design -->
   
</main>
<!-- END Main Container -->

<?php $__env->stopSection(); ?>





<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>