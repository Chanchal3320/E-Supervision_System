 

<?php $__env->startSection('title'); ?>

ESS || Supervisor Profile

<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>


<?php echo $__env->make('frontEnd.supervisor.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 <!-- Main Container -->
<main id="main-container" class="supervisor_main">
    <!-- Page Content -->
    <!-- User Info -->
    <div class="bg-image bg-image-bottom" style="background-image: url('assets/img/photos/photo13@2x.jpg');">
        <div class="bg-primary-dark-op py-30">
            <div class="content content-full text-center">
                <!-- Avatar -->
                <div class="mb-15">
                    <a class="img-link" href="">
                        <img class="img-avatar img-avatar96 img-avatar-thumb" src="<?php echo e(asset($profileById->supervisor_image)); ?>" alt="">
                    </a>
                </div>
                <!-- END Avatar -->

                <!-- Personal -->
                <h1 class="h3 text-white font-w700 mb-10"><?php echo e($profileById->supervisor_firstName.' ' . $profileById->supervisor_lastName); ?></h1>
                <h2 class="h5 text-white-op">
                    Email:  <a class="text-primary-light" href="javascript:void(0)"><?php echo e($profileById->email); ?></a>
                </h2>
                <!-- END Personal -->

                <!-- Actions -->
                
                <button type="button" class="btn btn-rounded btn-hero btn-sm btn-alt-primary mb-5">
                    <i class="fa fa-envelope-o mr-5"></i> Message
                </button>
                <!-- END Actions -->
            </div>
        </div>
    </div>
    <!-- END User Info -->

    <!-- Main Content -->
    <div class="content">
        <!-- Projects -->
        <h2 class="content-heading">
            
            <i class="si si-briefcase mr-5"></i> Researches Topics
        </h2>
         <!-- Bordered Table -->
         <div class="row">
            <div class="col-md-6 offset-md-3">
                   <div class="block">                        
                        <div class="block-content">
                            
                             <h3 style="text-align: center" class="text-success">
        
                                <?php echo e(Session::get('message')); ?>

                            </h3>


                            <?php

                            $supervisor_email = $profileById->email;

                            if ($supervisor_email == Auth::user()->email) {

                                ?>

                                <button id="ShowForm" type="button" class="btn btn-primary" data-toggle="modal" data-target="#research_modal" title="Add Research Topics"><i class="fa fa-plus"></i></button>
                            <?php }


                            ?>
                

                             




                            <table class="table table-dark table-bordered table-vcenter">
                                <thead>
                                    <tr>
                                        <th class="text-center" style="width: 50px;">SL</th>
                                        
                                      
                                        <th>Research Topics</th>
                                        <th>Action</th>                                       
                                        <!-- <th class="text-center" style="width: 100px;">Actions</th> -->
                                    </tr>
                                </thead> 

                                <?php
                                    $i = 1;

                                $supervisor_id = $profileById->supervisor_id;
                                // echo $supervisor_id ;


                                $researches = DB::table('researches')
                                        ->where('supervisor_id',$supervisor_id)
                                        ->get();

                                     
                                ?>                              
                                <tbody> 
                                    
                                   <?php $__currentLoopData = $researches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $research): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                          
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($research->research_topics); ?></td>
                                    <td class="text-center">

                                        
                                        <a href="<?php echo e(url('/supervisor/deleteResearch/'.$research->research_id)); ?>">
                                        <button id="ShowForm" type="button" class="btn btn-danger"   title="Edit"><i class="fa fa-trash"></i></button>
                                        </a>


                                        
                                       
                                        




                                    </td>
                                    
                                </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- END Bordered Table -->
            </div>
         </div>
        
        <!-- END Projects -->

        <!-- Colleagues -->
        <h2 class="content-heading">
            
            <i class="si si-users mr-5"></i> Counselling Information
        </h2>
        <div class="row items-push">

            <div class="col-md-8 offset-md-2">
                
                    <!-- Bordered Table -->
                    <div class="block">
                         <h3 style="text-align: center" class="text-success">
        
                                <?php echo e(Session::get('message')); ?>

                            </h3>
                

                            



                                <?php

                            $supervisor_email = $profileById->email;

                            if ($supervisor_email == Auth::user()->email) {

                                ?>

                                <button id="ShowForm" type="button" class="btn btn-success" data-toggle="modal" data-target="#counselling_modal" title="Add Research Topics"><i class="fa fa-plus"></i></button>
                            <?php }


                            ?>
                
                        
                        <div class="block-content">
                            <table class="table table-dark table-bordered table-vcenter">
                                <thead>
                                    <tr>
                                        <th class="text-center" style="width: 50px;">SL</th>
                                        
                                       
                                        <th>Counselling Day</th>                                       
                                        <th>Counselling Time</th>                                       
                                        <th>Action</th>                                       
                                        <!-- <th class="text-center" style="width: 100px;">Actions</th> -->
                                    </tr>
                                </thead>

                                <?php 
                                    $i = 1;

                                     $supervisor_id = $profileById->supervisor_id;
                                // echo $supervisor_id ;


                                $counsellings = DB::table('counsellings')
                                        ->where('supervisor_id',$supervisor_id)
                                        ->get();

                                ?>

                              
                                <tbody>
                                    <?php $__currentLoopData = $counsellings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counselling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  
                                  <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($counselling->counselling_day); ?></td>
                                    <td><?php echo e($counselling->counselling_time); ?></td>
                                    <td>
                                        



                                    <a href="<?php echo e(url('/supervisor/deleteCounselling/'.$counselling->counselling_id)); ?>"
                                         id="ShowForm" type="button" class="btn btn-danger"   title="Delete"><i class="fa fa-trash"></i></button>
                                        </a>



                                      
                                    </td>
                                  </tr>
                                  
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    



                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- END Bordered Table -->

            </div>
            
          
           
        </div>
        <!-- END Colleagues -->                   
    </div>
    <!-- END Main Content -->
    <!-- END Page Content -->
</main>
<!-- END Main Container -->

    <?php echo $__env->make('frontEnd.supervisor.supervisor.formResearch', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

    <?php echo $__env->make('frontEnd.supervisor.supervisor.formCounselling', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.supervisor.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>