

<!-- Modal -->
<div id="research" class="modal fade" role="dialog">
  <div class="modal-dialog"> 

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add Research Topics</h4>
      </div>
      <div class="modal-body">
          <form  method="post" id="research_form" data-toogle="validator">
              <?php echo csrf_field(); ?>
         <div class="input-group">
            <span class="input-group-addon">
                <i class="material-icons"></i>
            </span>
            <div class="form-group label-floating">
              <label class="control-label">Reaserch Topics <small>*</small></label>
              
              <input name="research_topics" id="research_topics" type="text" class="form-control">
            </div>
        </div> 

        <div class="input-group">
            <span class="input-group-addon">
                <i class="material-icons"></i>
            </span>
            <div class="form-group label-floating">
              <label class="control-label">Supervisor ID <small>*</small></label>
              
              <input name="supervisor_id" id="supervisor_id" type="text" class="form-control">
            </div>
        </div>




        </form>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-default">SUBMIT</button>
      </div>
    </div>

  </div>
</div>

                          