<!-- Codebase Core JS -->
        <script src="<?php echo e(asset('frontEnd/js/core/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('frontEnd/js/core/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('frontEnd/js/core/jquery.slimscroll.min.js')); ?>"></script>
        <script src="<?php echo e(asset('frontEnd/js/core/jquery.scrollLock.min.js')); ?>"></script>
        <script src="<?php echo e(asset('frontEnd/js/core/jquery.appear.min.js')); ?>"></script>
        <script src="<?php echo e(asset('frontEnd/js/core/jquery.countTo.min.js')); ?>"></script>
        <script src="<?php echo e(asset('frontEnd/js/core/js.cookie.min.j')); ?>s"></script>
        <script src="<?php echo e(asset('frontEnd/js/codebase.js')); ?>"></script>
        <script src="<?php echo e(asset('frontEnd/js/jquery.bootstrap.js')); ?>"></script>
        <script src="<?php echo e(asset('frontEnd/js/jquery.validate.min.js')); ?>"></script>
        <script src="<?php echo e(asset('frontEnd/js/material-bootstrap-wizard.js')); ?>"></script>


        <!-- Page JS Plugins -->
        <script src="<?php echo e(asset('frontEnd/js/plugins/chartjs/Chart.bundle.min.js')); ?>"></script>

        <!-- Page JS Code -->
        <script src="<?php echo e(asset('frontEnd/js/pages/be_pages_dashboard.js')); ?>"></script>


        <!-- Page JS Plugins -->
        <script src="<?php echo e(asset('frontEnd/js/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('frontEnd/js/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

        <!-- Page JS Code -->
        <script src="<?php echo e(asset('frontEnd/js/pages/be_tables_datatables.js')); ?>"></script>
        <script src="<?php echo e(asset('frontEnd/js/multi-step-form.js')); ?>"></script>

        
    <script src="<?php echo e(asset('frontEnd/validator/validator.min.js')); ?>"></script>

      
    <script src="<?php echo e(asset('frontEnd/dataTables/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontEnd/dataTables/js/dataTables.bootstrap.min.js')); ?>"></script>



<script>
    $('#sendMail').on('shown.bs.modal', function () {
  $('#message-text').trigger('focus')
})
</script>
