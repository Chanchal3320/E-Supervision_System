   <!-- Modal -->
  <div id="project_modal" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Project Info</h4>
        </div>
        <div class="modal-body">
           <form action="<?php echo e(url('/addProject')); ?>" method="post">
             <?php echo csrf_field(); ?>
          <div class="input-group">
              <span class="input-group-addon">
                  <i class="material-icons"></i>
              </span>
              <div class="form-group label-floating">
                <label class="control-label">Project Name <small>*</small></label>
                
                <input name="project_name" type="text" class="form-control">
              </div>
          </div>


          
           <div class="input-group">
                  <span class="input-group-addon">
                      <i class="material-icons"></i>
                  </span>
                  <div class="form-group label-floating">
                    <label class="control-label">Project Length (month)<small>*</small></label>
                    <input name="project_length"  type="text" class="form-control">
                  </div>
              </div>


              <div class="input-group">
                  <span class="input-group-addon">
                      <i class="material-icons"></i>
                  </span>
                  <div class="form-group label-floating">
                    <label class="control-label">Project Details <small>*</small></label>
                    <textarea name="project_details" id="" cols="20" rows="5" class="form-control"></textarea>
                  </div>
              </div>

           



        

        </div>
        <div class="modal-footer">
           
          <button type="submit" class="btn btn-success" >SUBMIT</button>
          
        </div>
          </form>
      </div>

    </div>
  </div>


