<?php $__env->startSection('title'); ?>

ESS || Add Department
 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>

 <h3 style="text-align: center" class="text-success">
        
        <?php echo e(Session::get('message')); ?>

    </h3>

<?php echo $__env->make('admin.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>




 <!-- Main Container -->
<main id="main-container">
    <!-- Page Content -->
    <div class="content">
        <!-- Default Table Style -->

        <h2 class="content-heading">Department List</h2>

      <button  type="button" class="btn btn-success" data-toggle="modal" data-target="#department_modal">ADD Dept.</button>
        
        <div class="col-md-6 offset-md-3">

        <!-- Bordered Table --> 
        <div class="block">
            
            <div class="block-content">
                <table class="table table-bordered table-vcenter">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 50px;">SL</th>
                            

                            <th class="text-center">Department Name</th>
                                                                   
                                                             
                            <th class="text-center" style="width: 100px;">Actions</th>
                        </tr>
                    </thead>


                    <?php 

                    $i = 1;

                    ?>

                  
                   

                    
                    <tbody>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        
                        <tr>
                              <td ><?php echo e($i++); ?></td>
                            
                            <td class="text-center"> <?php echo e($department->department_name); ?> </td>
                           
                            
                            
                            <td>

                             
                                <button  type="button" data-department_name="<?php echo e($department->department_name); ?>"
                                data-department_id="<?php echo e($department->department_id); ?>" data-toggle="modal" data-target="#edit_department" class="btn btn-info" ><i class="fa fa-edit"></i></button>
                                
                            </td>
                         </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       

                        

                         


                       
                       



                    </tbody>
                </table>
            </div>
        </div>
        <!-- END Bordered Table -->
        
        </div>
      
        <!-- END Default Table Style -->
    </div>
    <!-- END Page Content -->
</main>
<!-- END Main Container -->



<?php echo $__env->make('admin.faculty.formDepartment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.faculty.editDepartment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
   




<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>