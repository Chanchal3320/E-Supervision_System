 

<?php $__env->startSection('title'); ?>

SIS || Add Supervisor
 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>


<?php echo $__env->make('admin.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


  <!-- Main Container -->
            <main id="main-container">
                <!-- Page Content -->
                <!-- User Info -->
                <div class="bg-image bg-image-bottom" style="background-image: url('assets/img/photos/photo13@2x.jpg');">
                    <div class="bg-primary-dark-op py-30">
                        <div class="content content-full text-center">
                            <!-- Avatar -->
                            <div class="mb-15">
                                <a class="img-link" href="">
                                    <img class="img-avatar img-avatar96 img-avatar-thumb" src="<?php echo e(asset($profile->supervisor_image)); ?>" alt="">
                                </a>
                            </div>
                            <!-- END Avatar -->

                            <!-- Personal -->
                            <h1 class="h3 text-white font-w700 mb-10"><?php echo e($profile->supervisor_firstName.' ' . $profile->supervisor_lastName); ?></h1>
                            <h2 class="h5 text-white-op">
                                Email:  <a class="text-primary-light" href="javascript:void(0)"><?php echo e($profile->email); ?></a>
                            </h2>
                            <!-- END Personal -->

                            <!-- Actions -->
                            
                            <button type="button" class="btn btn-rounded btn-hero btn-sm btn-alt-primary mb-5">
                                <i class="fa fa-envelope-o mr-5"></i> Message
                            </button>
                            <!-- END Actions -->
                        </div>
                    </div>
                </div>
                <!-- END User Info -->

                <!-- Main Content -->
                <div class="content">
                    <!-- Projects -->
                    <h2 class="content-heading">
                        
                        <i class="si si-briefcase mr-5"></i> Researches Topics
                    </h2>
                     <!-- Bordered Table -->
                     <div class="row">
                     	<div class="col-md-6 offset-md-3">
                     		   <div class="block">                        
			                        <div class="block-content">
			                            <table class="table table-bordered table-vcenter">
			                                <thead>
			                                    <tr>
			                                        <th class="text-center" style="width: 50px;">SL</th>
			                                        
			                                      
			                                        <th>Research Topics</th>                                       
			                                        <!-- <th class="text-center" style="width: 100px;">Actions</th> -->
			                                    </tr>
			                                </thead> 

			                                <?php
			                                	$i = 1;
			                                ?>                              
			                                <tbody>                                
			                                <tr>
			                                	<td><?php echo e($i++); ?></td>
			                                	<td><?php echo e($profile->research_topics); ?></td>
			                                	
			                                </tr>
			                                </tbody>
			                            </table>
			                        </div>
			                    </div>
			                    <!-- END Bordered Table -->
                     	</div>
                     </div>
                 





















                    
                    <!-- END Projects -->

                    <!-- Colleagues -->
                    <h2 class="content-heading">
                        
                        <i class="si si-users mr-5"></i> Counselling Information
                    </h2>
                    <div class="row items-push">

                    	<div class="col-md-8 offset-md-2">
                    		
			                    <!-- Bordered Table -->
			                    <div class="block">
			                        
			                        <div class="block-content">
			                            <table class="table table-bordered table-vcenter">
			                                <thead>
			                                    <tr>
			                                        <th class="text-center" style="width: 50px;">SL</th>
			                                        
			                                       
			                                        <th>Counselling Day</th>                                       
			                                        <th>Counselling Time</th>                                       
			                                        <!-- <th class="text-center" style="width: 100px;">Actions</th> -->
			                                    </tr>
			                                </thead>

			                                <?php 
			                                	$i = 1;

			                                ?>

			                              
			                                <tbody>
			                                  
			                                  <tr>
			                                  	<td><?php echo e($i++); ?></td>
			                                  	<td><?php echo e($profile->counselling_day); ?></td>
			                                  	<td><?php echo e($profile->counselling_time); ?></td>
			                                  </tr>
			                                  
			                                    



			                                </tbody>
			                            </table>
			                        </div>
			                    </div>
			                    <!-- END Bordered Table -->

                    	</div>
                        
                      
                       
                    </div>
                    <!-- END Colleagues -->                   
                </div>
                <!-- END Main Content -->
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->





<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>