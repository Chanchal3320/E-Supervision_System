   <!-- Modal -->
  <div id="department_modal" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Department Info</h4>
        </div>
        <div class="modal-body">
          <form method="post" action="<?php echo e(url('/saveDepartmentInfo')); ?>">
              <?php echo csrf_field(); ?>
            <div class="block">
                
                <div class="block-content">
                    <div class="form-group row">
                        <div class="col-md-9">
                            <div class="form-material floating">
                                <input type="text" class="form-control" id="material-text2" name="department_name">
                                <label for="material-text2">Department Name</label>
                            </div>
                        </div>
                    </div>
                    

                  

                 
                </div>
            </div>
        </div>
        <div class="modal-footer">
           
          <button type="submit" class="btn btn-success" >SUBMIT</button>
          
        </div>
          </form>
      </div>

    </div>
  </div>


