 

<?php $__env->startSection('title'); ?>

ESS || Student Profile

<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>


<?php echo $__env->make('frontEnd.supervisor.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>




 <!-- Main Container -->
<main id="main-container" class="supervisor_main">
    <!-- Page Content -->
    <!-- User Info -->
    <div class="bg-image bg-image-bottom" style="background-image: url('assets/img/photos/photo13@2x.jpg');">
        <div class="bg-primary-dark-op py-30">
            <div class="content content-full text-center">
                <!-- Avatar -->
                <div class="mb-15">
                    <a class="img-link" href="">
                        <img class="img-avatar img-avatar96 img-avatar-thumb" 
                        src="<?php echo e(asset($studentProfileView->user_image)); ?>" alt="">
                    </a>
                </div>
                <!-- END Avatar -->

                <!-- Personal -->
                <h1 class="h3 text-white font-w700 mb-10"><?php echo e($studentProfileView->name); ?></h1>
                <h2 class="h5 text-white-op">
                    Email:  <a class="text-primary-light" href="javascript:void(0)"><?php echo e($studentProfileView->email); ?></a>
                </h2>
                <!-- END Personal -->

                <!-- Actions -->
                
                <button type="button" class="btn btn-rounded btn-hero btn-sm btn-alt-primary mb-5">
                    <i class="fa fa-envelope-o mr-5"></i> Message
                </button>
                <!-- END Actions -->
            </div>
        </div>
    </div>
    <!-- END User Info -->

    

       
            
          
           
        </div>
        <!-- END Colleagues -->                   
    </div>
    <!-- END Main Content -->
    <!-- END Page Content -->
</main>
<!-- END Main Container -->

   
  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.supervisor.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>