 

<?php $__env->startSection('title'); ?>

ESS || Supervisor List

<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>


<?php echo $__env->make('frontEnd.Student.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Main Container -->
<main id="main-container">

    

    <!-- Page Content -->
    <div class="content">
        <h2 class="content-heading">All Supervisor List</h2>
            <div class="row">

                <?php $__currentLoopData = $supervisors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    
                     <div class="card" >
                      <img class="card-img-top" src="<?php echo e(asset($supervisor ->supervisor_image)); ?>" alt="Card image cap" >
                      <div class="card-body">
                        <h5 class="card-title text-center"><?php echo e($supervisor -> supervisor_firstName.' ' .' '.$supervisor -> supervisor_lastName); ?></h5>
                        <p class="card-text text-center">Phone: <?php echo e($supervisor -> supervisor_phone); ?> </p>
                        <p class="card-text text-center">Email: <?php echo e($supervisor ->email); ?> </p>


                        <?php 



                            $check = DB::table('notifications')
                                ->where('user_requested','=', $supervisor->id)
                                ->where('requester','=',Auth::user()->id)
                                ->first();


                            if ($check == '') {
                        ?>



                        <a href="<?php echo e(url('/student/sendRequest/'.$supervisor->id)); ?>" class="btn btn-rounded  btn-sm btn-alt-success">Send Request</a>

                        <?php 
                        }

                        else{  ?>

                            

                            <button class="btn btn-rounded  btn-sm btn-alt-success" disabled > Request Sent</button>

                            <?php }  ?>

                        <a href="<?php echo e(url('/student/viewSupervisorProfile/'.$supervisor->supervisor_id)); ?>" class="btn btn-rounded  btn-sm btn-alt-primary">View Profile</a>
                      </div>
                    </div>
                </div>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

           
       

       
    </div>
    <!-- END Page Content -->
</main>
<!-- END Main Container -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.Student.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>