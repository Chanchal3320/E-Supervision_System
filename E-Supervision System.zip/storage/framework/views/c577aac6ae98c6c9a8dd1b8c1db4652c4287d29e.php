 

<?php $__env->startSection('title'); ?>

ESS || Supervisor List

<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>


<?php echo $__env->make('frontEnd.Student.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	
<!-- Main Container -->
<main id="main-container">

    

    <!-- Page Content -->
    <div class="content">
       
            <div class="row">

            	<div class="col-md-6">
            		<div class="msg_body">
            			<?php echo e($msg); ?>

            		</div>
            	</div>

                
            </div>
    </div>
    <!-- END Page Content -->



</main>
<!-- END Main Container -->








<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.Student.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>