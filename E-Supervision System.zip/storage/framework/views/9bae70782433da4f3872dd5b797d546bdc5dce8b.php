<?php $__env->startSection('title'); ?>

SIS || Student List

<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>


<?php echo $__env->make('frontEnd.Student.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Main Container -->
            <main id="main-container">

                

                <!-- Page Content -->
                <div class="content">
                    <h2 class="content-heading">All Student Group List</h2>

                    <!-- Dynamic Table Full -->
                    <div class="block">
                        
                        <div class="block-content block-content-full">
                            <!-- DataTables init on table by adding .js-dataTable-full class, functionality initialized in js/pages/be_tables_datatables.js -->
                            <table class="table table-bordered table-striped table-vcenter js-dataTable-full">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Student Name</th> 
                                        <th>Student ID</th> 
                                        <th>Project Title</th> 
                                        <th>Action</th>                                       
                                        
                                    </tr>
                                </thead>
                                <?php 

                                    $i = 1;
                                ?>
                               
                                <tbody>
                                   <?php $__currentLoopData = $studentGroupList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <tr>
                                          <td rowspan="3"><?php echo e($i++); ?></td>



                                        <td class="student_name"><?php echo e($studentGroup->fStudent_name); ?></td>
                                        <td class="student_id"><?php echo e($studentGroup->fStudent_sId); ?></td>
                                        <td class="text-center"><?php echo e($studentGroup->project_name); ?></td>
                                        
                                        <td rowspan="3">

                                         <a href="<?php echo e(url('/viewGroupDetails/'.$studentGroup->project_id)); ?>" class="btn btn-info"  title="View">
                                                <span class="fa fa-eye"></span>
                                            </a> 
                                        </td>
                                     </tr>

                                     <tr>
                                        <td class="student_name"><?php echo e($studentGroup->sStudent_name); ?></td>
                                        <td class="student_id"><?php echo e($studentGroup->sStudent_sId); ?></td>
                                        
                                     </tr>


                                     <tr>
                                        <td class="student_name"><?php echo e($studentGroup->tStudent_name); ?></td> 
                                        <td class="student_id"><?php echo e($studentGroup->tStudent_sId); ?></td> 
                                     </tr>

                                     


                                   
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- END Dynamic Table Full -->

                   

                   
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.Student.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>