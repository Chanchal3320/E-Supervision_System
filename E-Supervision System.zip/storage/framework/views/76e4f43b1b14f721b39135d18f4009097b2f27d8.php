<!doctype html>
 <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="no-focus"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
     <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo $__env->yieldContent('title'); ?></title>

        

        <!-- Icons -->
        <!-- The following icons can be replaced with your own, they are used by desktop and mobile browsers -->
       <?php echo $__env->make('frontEnd.supervisor.includes.link', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- You can include a specific file from css/themes/ folder to alter the default color theme of the template. eg: -->
        <!-- <link rel="stylesheet" id="css-theme" href="backEnd/css/themes/flat.min.css"> -->
        <!-- END Stylesheets -->
    </head>
    <body>
        
        <div id="page-container" class="sidebar-o side-scroll page-header-modern main-content-boxed">
            

           
           
           
           <?php echo $__env->make('frontEnd.supervisor.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
           <?php echo $__env->make('frontEnd.supervisor.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

       

            <?php echo $__env->yieldContent('mainContent'); ?>

            <?php echo $__env->make('frontEnd.supervisor.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <!-- END Page Container -->

        <?php echo $__env->make('frontEnd.supervisor.includes.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>