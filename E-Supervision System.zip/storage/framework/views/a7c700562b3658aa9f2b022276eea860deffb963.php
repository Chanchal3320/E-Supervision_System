<?php $__env->startSection('title'); ?>

ESS || ADD Counselling

<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>


<?php echo $__env->make('frontEnd.supervisor.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!-- Main Container -->
<main id="main-container" class="supervisor_main">

        
    <h3 style="text-align: center" class="text-success">
        
        <?php echo e(Session::get('message')); ?>

    </h3>

    <!-- Page Content -->
    <div class="content">
        <!-- Material Design -->
        <h2 class="content-heading">ADD Supervisor Counselling INFORMATION</h2>  
            <div class="row">
                           
                <div class="col-md-8 offset-md-2">

                  <?php 

                  $supervisor_id = Session::get('supervisor_id');
                  
                  ?>

                      <form action="<?php echo e(url('/supervisor/saveFirstCounselling')); ?>" method="post">
             <?php echo csrf_field(); ?>
          <div class="input-group">
              <span class="input-group-addon">
                  <i class="material-icons"></i>
              </span>
              <div class="form-group label-floating">
                
                
                <input type="hidden" value="<?php echo e($supervisor_id); ?>" name="supervisor_id" type="text" class="form-control">
              </div>
          </div>


          
           <div class="input-group">
                  <span class="input-group-addon">
                      <i class="material-icons"></i>
                  </span>
                  <div class="form-group label-floating">
                    <label class="control-label">Counselling Day <small>*</small></label>
                    <input name="counselling_day" type="text" class="form-control">
                  </div>
              </div>


              <div class="input-group">
                  <span class="input-group-addon">
                      <i class="material-icons"></i>
                  </span>
                  <div class="form-group label-floating">
                    <label class="control-label">Couselling Time <small>*</small></label>
                    <input name="counselling_time" type="text" class="form-control">
                  </div>
              </div>

           



        

        </div>
        <div class="modal-footer">
           
          <button type="submit" class="btn btn-success" >SUBMIT</button>
        </div>
          </form>


                   
                </div> <!-- wizard container -->
            </div>



    </div>
        <!-- END Material Design -->
   
</main>
<!-- END Main Container -->





<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.supervisor.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>