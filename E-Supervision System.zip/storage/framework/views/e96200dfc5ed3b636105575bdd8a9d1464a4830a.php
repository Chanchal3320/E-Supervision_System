<?php $__env->startSection('title'); ?>

SIS || Add Supervisor
 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>


<?php echo $__env->make('admin.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


  <!-- Main Container -->
            <main id="main-container">
                <!-- Page Content -->
                <div class="content">
                    <!-- Default Table Style -->
                    <h2 class="content-heading">Supervisor List</h2>

                    

                    


                    <!-- Bordered Table -->
                    <div class="block">
                        
                        <div class="block-content">
                            <table class="table table-bordered table-vcenter">
                                <thead>
                                    <tr>
                                        <th class="text-center" style="width: 50px;">#</th>
                                        <th>Image</th>
                                        <th>Full Name</th>
                                        
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Designation</th>
                                        <th>Department</th>
                                        
                                       
                                        <th class="text-center" style="width: 100px;">Actions</th>
                                    </tr>
                                </thead>

                                <?php 
                                  $i = 1;

                                ?>
                                <tbody>
                                  <?php $__currentLoopData = $supervisors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  
                                  
                                    
                                    
                                    <tr>
                                        <th class="text-center" scope="row"><?php echo e($i++); ?></th>
                                        <td><img src="<?php echo e(asset($supervisor ->supervisor_image)); ?>" alt="" width="50px" height="50px"></td>
                                        <td><?php echo e($supervisor -> supervisor_firstName.' ' .' '.$supervisor -> supervisor_lastName); ?></td>
                                        
                                        <td><?php echo e($supervisor -> email); ?></td>
                                        <td><?php echo e($supervisor -> supervisor_phone); ?></td>
                                        <td><?php echo e($supervisor ->supervisor_designation); ?></td>
                                        <td><?php echo e($supervisor ->supervisor_department); ?></td>
                                        
                                        
                                        <td >
                                            <div class="btn-group">
                                              <a href="<?php echo e(url('/showProfile/'.$supervisor->supervisor_id)); ?>"><button type="button" class="btn btn-sm btn-warning"  title="Show Profile">
                                                    <i class="fa fa-eye"></i>
                                                </button> </a>  &nbsp;


                                                <a href="<?php echo e(url('/editProfile/'.$supervisor->supervisor_id)); ?>"><button type="button" class="btn btn-sm btn-info"  title="Edit Profile">
                                                    <i class="fa fa-pencil"></i>
                                                </button>  </a> &nbsp;


                                               <a href="<?php echo e(url('/deleteProfile/'.$supervisor->supervisor_id)); ?>"> <button type="button" class="btn btn-sm btn-danger"  title="Delete Profile">
                                                    <i class="fa fa-times"></i>
                                                </button></a>

                                            </div>
                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- END Bordered Table -->

                  
                    <!-- END Default Table Style -->
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->



    
   




<?php $__env->stopSection(); ?>

         
<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>