<?php $__env->startSection('title'); ?>

ESS || All Project List

<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>


<?php echo $__env->make('frontEnd.supervisor.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Main Container -->
            <main id="main-container" class="supervisor_main">

                

                <!-- Page Content -->
                <div class="content">
                    <h2 class="content-heading">All Project List</h2>

                     <!-- Bordered Table --> 
        <div class="block">
            
            <div class="block-content">
                <table class="table table-bordered table-vcenter">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 50px;">SL</th>
                            

                            <th class="text-center">Project Name</th>
                            <th class="text-center">Duration</th>
                            <th class="text-center">Project Description</th>
                                                                   
                            <th class="text-center">Status</th>                                       
                           
                        </tr>
                    </thead>
                    <?php
                        $i = 1;
                    ?>

                    
                    <tbody>
                         <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <tr>
                              <td ><?php echo e($i++); ?></td>
                            
                            <td class="text-center"><?php echo e($project->project_name); ?></td>
                            <td class="text-center"><?php echo e($project->project_length); ?> Month</td>
                            <td class="text-center"><?php echo e($project->project_details); ?></td>
                           
                            <td class="text-center">

                                 <?php 
                                    if ($project->status == 1) {
                                        ?>

                                        <a href="<?php echo e(url('/supervisor/projectStatus/'.$project->project_id)); ?>"><button class="btn btn-sm btn-success" id="btnActive"><span >running</span></button></a>


                                        <?php
                                    }
                                    else{ ?>

                                         <button class="btn btn-sm btn-danger" id="btnActive"><span >completed</span></button>

                                        <?php
                                    }

                                  ?>

                            </td>
                            
                            
                         </tr>

                        

                         


                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                    </tbody>
                </table>
            </div>
        </div>
        <!-- END Bordered Table -->

      
                   

                   
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.supervisor.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>