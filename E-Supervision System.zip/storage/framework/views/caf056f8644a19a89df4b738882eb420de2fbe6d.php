<?php $__env->startSection('title'); ?>

ESS || Student Profile
 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>
<?php echo $__env->make('frontEnd.student.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


 <!-- Main Container -->
<main id="main-container" >
    <!-- Page Content -->
    <!-- User Info -->
    <div class="bg-image bg-image-bottom" style="background-image: url('assets/img/photos/photo13@2x.jpg');">
        <div class="bg-primary-dark-op py-30">
            <div class="content content-full text-center">
                <!-- Avatar -->
                <div class="mb-15">
                    <a class="img-link" href="">
                        <img class="img-avatar img-avatar96 img-avatar-thumb" src="<?php echo e(asset($studentProfile->user_image)); ?>" alt="">
                    </a>
                </div>
                <!-- END Avatar -->

                <!-- Personal -->
                <h1 class="h3 text-white font-w700 mb-10"><?php echo e($studentProfile->name); ?></h1>
                <h2 class="h5 text-white-op">
                    Email:  <a class="text-primary-light" href="javascript:void(0)"><?php echo e($studentProfile->email); ?></a>
                </h2>
                <!-- END Personal -->

                <!-- Actions -->
                
                
                <!-- END Actions -->
            </div>
        </div>
    </div>
    <!-- END User Info -->

  
        
       

</main>
<!-- END Main Container -->

  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.Student.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>