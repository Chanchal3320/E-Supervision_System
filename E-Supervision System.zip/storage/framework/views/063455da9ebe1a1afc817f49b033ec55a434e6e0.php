<?php $__env->startSection('title'); ?>

ESS || Add Project Info
 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>

 <h3 style="text-align: center" class="text-success">
        
        <?php echo e(Session::get('message')); ?>

    </h3>

<?php echo $__env->make('admin.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>




 <!-- Main Container -->
<main id="main-container">
    <!-- Page Content -->
    <div class="content">
        <!-- Default Table Style -->

        <h2 class="content-heading">Project List</h2>

      
        


        <!-- Bordered Table --> 
        <div class="block">
            
            <div class="block-content">
                <table class="table table-bordered table-vcenter">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 50px;">SL</th>
                            

                            <th class="text-center">Project Name</th>
                            
                            <th class="text-center">Project Length</th>
                            <th class="text-center">Project Details</th>                             
                            <th class="text-center">Status</th>                                       
                            <th class="text-center" style="width: 100px;">Actions</th>
                        </tr>
                    </thead>
                    <?php
                        $i = 1;
                    ?>

                    
                    <tbody>
                         <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <tr>
                              <td ><?php echo e($i++); ?></td>
                            
                            <td class="text-center"><?php echo e($project->project_name); ?></td>
                            <td class="text-center"><?php echo e($project->project_length); ?> Month</td>
                            <td class="text-center"><?php echo e($project->project_details); ?></td>
                           
                            <td class="d-none d-sm-table-cell">
                                
                                   <?php 
                                    if ($project->status == 1) {
                                        ?>

                                        <a href="<?php echo e(url('/projectStatus/'.$project->project_id)); ?>"><button class="btn btn-sm btn-success" id="btnActive"><span >running</span></button></a>


                                        <?php
                                    }
                                    else{ ?>

                                         <button class="btn btn-sm btn-danger" id="btnActive"><span >completed</span></button>


                                        <?php

                                    }

                                  ?>
                                
                            </td> 
                            
                            <td>

                             <a href="<?php echo e(url('/viewProjectInfo/'.$project->project_id)); ?>"   title="View">
                                    

                                <button  type="button" class="btn btn-info" ><i class="fa fa-eye"></i></button>
                                </a> 
                            </td>
                         </tr>

                        

                         


                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                    </tbody>
                </table>
            </div>
        </div>
        <!-- END Bordered Table -->

      
        <!-- END Default Table Style -->
    </div>
    <!-- END Page Content -->
</main>
<!-- END Main Container -->




    
   




<?php $__env->stopSection(); ?>

         
<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>