<?php $__env->startSection('title'); ?>

SIS || Add Supervisor
 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mainContent'); ?>

 <h3 style="text-align: center" class="text-success">
        
        <?php echo e(Session::get('message')); ?>

    </h3>

<?php echo $__env->make('admin.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>




 <!-- Main Container -->
            <main id="main-container">
                <!-- Page Content -->
                <div class="content">
                    <!-- Default Table Style -->
                    <h2 class="content-heading">Supervisor Couselling List</h2>

                    <div class="Research_coun">
                    <a href="<?php echo e(url('/allResearch')); ?>">
                        <button  class="btn btn-sm btn-primary" >
                         Research Topics
                        </button> 
                    </a>
                </div>

                    
                  <button id="ShowForm" type="button" class="btn btn-success" data-toggle="modal" data-target="#counselling_modal"><i class="fa fa-plus"></i></button>
                    


                    <!-- Bordered Table -->
                    <div class="block">
                        
                        <div class="block-content">
                            <table class="table table-bordered table-vcenter">
                                <thead>
                                    <tr>
                                        <th class="text-center" style="width: 50px;">#</th>
                                        
                                        <th>Supervisor ID</th>
                                        <th>Counselling Day</th>                                       
                                        <th>Counselling Time</th>                                       
                                        <th class="text-center" style="width: 100px;">Actions</th>
                                    </tr>
                                </thead>

                               <?php 
                                $i = 1;

                               ?>
                                <tbody>
                                  
                                  
                                  
                                    <?php $__currentLoopData = $counsellings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counselling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <tr>
                                        <th class="text-center" scope="row"><?php echo e($i++); ?></th>
                                       
                                        <td><?php echo e($counselling->supervisor_id); ?></td>
                                        <td><?php echo e($counselling->counselling_day); ?></td>
                                        <td><?php echo e($counselling->counselling_time); ?></td>
                                        
                                        
                                        
                                        
                                        <td class="text-center">
                                            <div class="btn-group">
                                              
                                                <button type="button" class="btn btn-sm btn-info" data-toggle="tooltip" title="Edit">
                                                    <i class="fa fa-pencil"></i>
                                                </button>&nbsp;
                                                <button type="button" class="btn btn-sm btn-danger" data-toggle="tooltip" title="Delete">
                                                    <i class="fa fa-times"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                               




                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- END Bordered Table -->

                  
                    <!-- END Default Table Style -->
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->


<?php echo $__env->make('admin.supervisor.formCounselling', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
   




<?php $__env->stopSection(); ?>

         
<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>